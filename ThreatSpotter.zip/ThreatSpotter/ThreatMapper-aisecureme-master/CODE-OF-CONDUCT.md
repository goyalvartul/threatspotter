## Community Code of Conduct

Weaveworks follows the [CNCF Code of Conduct](https://github.com/cncf/foundation/blob/master/code-of-conduct.md).

Instances of abusive, harassing, or otherwise unacceptable behavior
may be reported by contacting a Weaveworks project maintainer, or
Alexis Richardson alexis@weave.works.

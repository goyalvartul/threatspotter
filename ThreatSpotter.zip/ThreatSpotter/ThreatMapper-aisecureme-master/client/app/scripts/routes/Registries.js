import React, {useState, useEffect} from 'react';
import {Table, Button, Modal} from 'antd';
import 'antd/dist/antd.css';
import Loader from '../components/Loader';
import Header from '../components/header';
import './styles.css';

export default function Registries() {
  const [isLoading, setIsLoading] = useState(true);
  const [isShowMoal, setIsShowMoal] = useState(false);
  const [data, setData] = useState([]);
  const [lastUpdated, setLastUpdated] = useState('');
  const columns = [
    { dataIndex: 'Profile', sorter: (a, b) => a.Profile - b.Profile, title: 'Profile' },
    { dataIndex: 'Account Number', title: 'Account Number' },
    { dataIndex: 'Control', title: 'Control' },
    { dataIndex: 'Message', title: 'Message' },
    { dataIndex: 'Severity', sorter: (a, b) => a.Severity - b.Severity, title: 'Severity' },
    { dataIndex: 'Status', title: 'Status' },
    { dataIndex: 'Scored', title: 'Scored' },
    { dataIndex: 'Control ID', title: 'Control ID' },
    { dataIndex: 'Region', title: 'Region' },
    { dataIndex: 'Compliance', title: 'Compliance' }
  ];
  const getLastReport = (refresh = false) => {
    const {hostname} = window.location;
    // TODO the final endpoint depends on want run the scanning agian or last stored one
    const endpoint = refresh ? `http://${hostname}:4041/api/aws/scan?run_updated_scan=true` : `http://${hostname}:4041/api/aws/scan`;
    // Send get request to get the aws sanning result
    fetch(endpoint)
      .then(response => response.json())
      .then((res) => {
        if (res.status) {
          setIsLoading(false);
          setIsShowMoal(false);
          setData(res.report);
          setLastUpdated(res.lastUpdated);
        }
      })
      .catch(() => {
        setIsLoading(false);
      });
  };

  /**
   * Refresh Ccnfirmation modal
   */
  const RefreshConfirmationModal = () => (
    <Modal
      visible={isShowMoal}
      width={600}
      closable={false}
      style={{borderRadius: 10}}
      onOk={() => {
        getLastReport(true);
        setIsShowMoal(false);
      }}
      onCancel={() => setIsShowMoal(false)}
      okText="Yes, sure"
      cancelText="Cancel"
    >
      <div>
        <h2>Scanning may takes 1 hour .. so are you sure want to run scanning ?</h2>
      </div>
    </Modal>
  );

  useEffect(() => {
    getLastReport();
  }, []);

  return (
    <div>
      <Header title="Registries" />
      {
      isLoading
        ? <Loader />
        : (
          <div style={{padding: 30}}>
            <div style={{
              alignItems: 'center', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15
            }}>
              <h3 style={{color: '#676767'}}>
                {`Last Update : ${lastUpdated}`}
              </h3>
              <Button
                style={{
                  alignItems: 'center', borderRadius: 6, display: 'flex', justifyContent: 'center'
                }}
                onClick={() => setIsShowMoal(true)}
              >
                Refresh
                <img
                  src={require('../../images/refresh.svg')}
                  style={{
                    height: 20, marginLeft: 5, width: 20
                  }}
                  alt="Refresh"
                />
              </Button>
            </div>
            <Table
              dataSource={data}
              columns={columns}
              loading={isLoading}
              scroll={{ x: '88%', y: 565 }}
            />
            <RefreshConfirmationModal />
          </div>
        )
      }
    </div>
  );
}

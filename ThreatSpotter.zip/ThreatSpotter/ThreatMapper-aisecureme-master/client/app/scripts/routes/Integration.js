import React from 'react';

export default function Integration() {
  return (
    <div>
      <h4>Integration</h4>
    </div>
  );
}

import React from 'react';

export default function Management() {
  return (
    <div>
      <h4>Management</h4>
    </div>
  );
}

import React from 'react';

export default function Vulnerabilities() {
  return (
    <div>
      <h4>Vulnerabilities</h4>
    </div>
  );
}

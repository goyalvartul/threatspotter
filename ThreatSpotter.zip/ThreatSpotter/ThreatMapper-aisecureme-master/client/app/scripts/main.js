import '@babel/polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import {
  BrowserRouter as Router, Switch, Route
} from 'react-router-dom';
import { Provider } from 'react-redux';
import '../images/favicon.ico';
import configureStore from './stores/configureStore';
import Fonts from './fonts';
import Integration from './routes/Integration';
import Management from './routes/Management';
import Vulnerabilities from './routes/Vulnerabilites';
import Registries from './routes/Registries';

const store = configureStore();

function renderApp() {
  const App = require('./components/app').default;

  ReactDOM.render(
    (
      <Provider store={store}>
        <Fonts />
        <Router>
          <Switch>
            <App />
            <Route
              path="/vulnerabilites"
              render={() => (<Vulnerabilities />)}
            />
            <Route
              path="/registries"
              render={() => (<Registries />)}
            />
            <Route
              path="/integration"
              render={() => (<Integration />)}
            />
            <Route
              path="/management"
              render={() => (<Management />)}
            />
          </Switch>
        </Router>
      </Provider>
    ), document.getElementById('app')
  );
}

renderApp();
if (module.hot) {
  module.hot.accept('./components/app', renderApp);
}

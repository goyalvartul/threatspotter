import debug from 'debug';
import React from 'react';
import classNames from 'classnames';
import {
  PieChart, Pie, Cell,
} from 'recharts';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Map as makeMap } from 'immutable';
import { noop } from 'lodash';
import { clickCloseDetails, clickShowTopologyForNode } from '../actions/request-actions';
import { brightenColor, getNeutralColor, getNodeColorDark } from '../utils/color-utils';
import { isGenericTable, isPropertyList } from '../utils/node-details-utils';
import { resetDocumentTitle, setDocumentTitle } from '../utils/title-utils';

import Overlay from './overlay';
import MatchedText from './matched-text';
import NodeDetailsControls from './node-details/node-details-controls';
import NodeDetailsGenericTable from './node-details/node-details-generic-table';
import NodeDetailsPropertyList from './node-details/node-details-property-list';
import NodeDetailsHealth from './node-details/node-details-health';
import NodeDetailsInfo from './node-details/node-details-info';
import NodeDetailsRelatives from './node-details/node-details-relatives';
import NodeDetailsTable from './node-details/node-details-table';
import Warning from './warning';


const log = debug('scope:node-details');
const COLORS = ['#00C49F', '#FFBB28', 'red'];
const RADIAN = Math.PI / 180;
const renderCustomizedLabel = ({
  cx, cy, midAngle, innerRadius, outerRadius, percent
}) => {
  const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + radius * Math.cos(-midAngle * RADIAN);
  const y = cy + radius * Math.sin(-midAngle * RADIAN);

  return (
    <text x={x} y={y} fill="white" textAnchor={x > cx ? 'start' : 'end'} dominantBaseline="central">
      {`${(percent * 100).toFixed(0)}%`}
    </text>
  );
};
function getTruncationText(count) {
  return 'This section was too long to be handled efficiently and has been truncated'
  + ` (${count} extra entries not included). We are working to remove this limitation.`;
}

class NodeDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isScanning: false,
      scanVulData: [
        { name: 'Low', value: 0 },
        { name: 'Medium', value: 0 },
        { name: 'High', value: 0 },
      ],
      showScanningInfo: false,
      targets: [],
      test: false
    };
  }

  handleClickClose = (ev) => {
    ev.preventDefault();
    this.props.clickCloseDetails(this.props.nodeId);
  }

  handleShowTopologyForNode = (ev) => {
    ev.preventDefault();
    this.props.clickShowTopologyForNode(this.props.topologyId, this.props.nodeId);
  }

  componentDidMount() {
    this.updateTitle();
  }

  componentWillUnmount() {
    resetDocumentTitle();
  }

  renderTools() {
    const showSwitchTopology = this.props.nodeId !== this.props.selectedNodeId;
    const topologyTitle = `View ${this.props.label} in ${this.props.topologyId}`;

    return (
      <div className="node-details-tools-wrapper">
        <div className="node-details-tools">
          {showSwitchTopology
            && (
            <i
              title={topologyTitle}
              className="fa fa-long-arrow-alt-left"
              onClick={this.handleShowTopologyForNode}>
              <span>
Show in
                <span>{this.props.topologyId.replace(/-/g, ' ')}</span>
              </span>
            </i>
            )
          }
          <i
            title="Close details"
            className="fa fa-times close-details"
            onClick={this.handleClickClose}
          />
        </div>
      </div>
    );
  }

  renderLoading() {
    const node = this.props.nodes.get(this.props.nodeId);
    const label = node ? node.get('label') : this.props.label;
    // NOTE: If we start the fa-spin animation before the node details panel has been
    // mounted, the spinner is displayed blurred the whole time in Chrome (possibly
    // caused by a bug having to do with animating the details panel).
    const spinnerClassName = classNames('fa fa-circle-notch', { 'fa-spin': this.props.mounted });
    const nodeColor = (node
      ? getNodeColorDark(node.get('rank'), label, node.get('pseudo'))
      : getNeutralColor());
    const tools = this.renderTools();
    const styles = {
      header: {
        backgroundColor: nodeColor
      }
    };

    return (
      <div className="node-details">
        {tools}
        <div className="node-details-header" style={styles.header}>
          <div className="node-details-header-wrapper">
            <h2 className="node-details-header-label truncate">
              {label}
            </h2>
            <div className="node-details-relatives truncate">
              Loading...
            </div>
          </div>
        </div>
        <div className="node-details-content">
          <div className="node-details-content-loading">
            <span className={spinnerClassName} />
          </div>
        </div>
      </div>
    );
  }

  renderNotAvailable() {
    const tools = this.renderTools();
    return (
      <div className="node-details">
        {tools}
        <div className="node-details-header node-details-header-notavailable">
          <div className="node-details-header-wrapper">
            <h2 className="node-details-header-label">
              {this.props.label}
            </h2>
            <div className="node-details-relatives truncate">
              n/a
            </div>
          </div>
        </div>
        <div className="node-details-content">
          <p className="node-details-content-info">
            <strong>{this.props.label}</strong>
            {' '}
not found!
          </p>
        </div>
        <Overlay faded={this.props.transitioning} />
      </div>
    );
  }

  render() {
    if (this.props.notFound) {
      return this.renderNotAvailable();
    }

    if (this.props.details) {
      return this.renderDetails();
    }

    return this.renderLoading();
  }

  renderDetails() {
    const {
      details, nodeControlStatus, nodeMatches = makeMap(), topologyId
    } = this.props;
    const showControls = details.controls && details.controls.length > 0;
    const nodeColor = getNodeColorDark(details.rank, details.label, details.pseudo);
    const {error, pending} = nodeControlStatus ? nodeControlStatus.toJS() : {};
    const tools = this.renderTools();
    const styles = {
      controls: {
        backgroundColor: brightenColor(nodeColor)
      },
      header: {
        backgroundColor: nodeColor
      }
    };

    return (
      <div className="tour-step-anchor node-details">
        {tools}
        <div className="node-details-header" style={styles.header}>
          <div className="node-details-header-wrapper">
            <h2 className="node-details-header-label truncate" title={details.label}>
              <MatchedText text={details.label} match={nodeMatches.get('label')} />
            </h2>
            <div className="node-details-header-relatives">
              {details.parents && (
              <NodeDetailsRelatives
                matches={nodeMatches.get('parents')}
                relatives={details.parents} />
              )}
            </div>
          </div>
        </div>
        {showControls
          && (
          <div className="tour-step-anchor node-details-controls-wrapper" style={styles.controls}>
            <NodeDetailsControls
              nodeId={this.props.nodeId}
              controls={details.controls}
              pending={pending}
              topologyId={topologyId}
              startScanContainer={() => this.scanContainer()}
              onPressHostScanButton={() => this.scanHost()}
              error={error} />
          </div>
          )
        }

        <div className="node-details-content">
          {this.state.showScanningInfo
            && (
            <div className="node-details-tabs">
              <div className="node-general-details" onClick={() => this.setState({showScanningInfo: false})}>
                General Details
              </div>
              <div className="node-scan-details" onClick={() => this.setState({showScanningInfo: true})}>
                Scanning Details
              </div>
            </div>
            )
          }
          <div style={{display: this.state.showScanningInfo ? 'none' : 'block'}}>
            {details.metrics
              && (
              <div className="node-details-content-section">
                <div className="node-details-content-section-header">Status</div>
                <NodeDetailsHealth
                  metrics={details.metrics}
                  topologyId={topologyId}
                  />
              </div>
              )
            }
            {details.metadata
              && (
              <div className="node-details-content-section">
                <div className="node-details-content-section-header">Info</div>
                <NodeDetailsInfo rows={details.metadata} matches={nodeMatches.get('metadata')} />
              </div>
              )
            }

            {details.connections && details.connections.filter(cs => cs.connections.length > 0)
              .map(connections => (
                <div className="node-details-content-section" key={connections.id}>
                  <NodeDetailsTable
                    {...connections}
                    nodes={connections.connections}
                    nodeIdKey="nodeId"
                  />
                </div>
              ))}

            {details.children && details.children.map(children => (
              <div className="node-details-content-section" key={children.topologyId}>
                <NodeDetailsTable {...children} />
              </div>
            ))}

            {details.tables && details.tables.length > 0 && details.tables.map((table) => {
              if (table.rows.length > 0) {
                return (
                  <div className="node-details-content-section" key={table.id}>
                    <div className="node-details-content-section-header">
                      {table.label && table.label.length > 0 && table.label}
                      {table.truncationCount > 0
                        && (
                        <span
                          className="node-details-content-section-header-warning">
                          <Warning text={getTruncationText(table.truncationCount)} />
                        </span>
                        )
                      }
                    </div>
                    {this.renderTable(table)}
                  </div>
                );
              }
              return null;
            })}
          </div>
          <div style={{display: this.state.showScanningInfo ? 'block' : 'none'}}>
            {
              this.state.isScanning
                ? <h4 style={{fontSize: 18, marginTop: 35, textAlign: 'center'}}> Scanning.... </h4>
                : this.renderScanningResult()
            }
          </div>
          {this.props.renderNodeDetailsExtras({ details, topologyId })}
        </div>

        <Overlay faded={this.props.transitioning} />
      </div>
    );
  }

  /**
   * render scanning result according to vulnerabilities length
   */
  renderScanningResult() {
    return this.state.targets.length === 0
      ? <h3 style={{textAlign: 'center'}}>There are no vulnerabilities</h3>
      : (
        <>
          <h3>Vulnerabilities Chart : </h3>
          <PieChart width={490} height={150} style={{alignSelf: 'center', display: 'flex'}}>
            <Pie
              data={this.state.scanVulData}
              cx={100}
              cy={100}
              label={renderCustomizedLabel}
              dataKey="value"
              startAngle={180}
              endAngle={0}
              outerRadius={80}
            >
              {
                this.state.scanVulData?.map((item2, index) => (
                  <Cell fill={COLORS[index % COLORS.length]} />
                ))
              }
            </Pie>
          </PieChart>
          { this.state.targets.map(target => this.renderVulnerabilities(target)) }
        </>
      );
  }

  /**
   * render vulns
   */
  renderVulnerabilities(target) {
    this.state.test = true;
    return target.Vulnerabilities?.map((item, key) => (
      <div key={item.id} style={{borderBottom: '1px solid gray'}}>
        <h3 style={{color: 'red'}}>{`(${key + 1}) - ${item.VulnerabilityID} `}</h3>
        <h3>{item.Title}</h3>
        <h3>{item.Description}</h3>
        <div style={{alignItems: 'center', display: 'flex', flexDirection: 'row'}}>
          <h4>Package Name : </h4>
          <h3 style={{color: 'blueviolet', marginLeft: 4}}>{item.PkgName}</h3>
        </div>
        <div style={{alignItems: 'center', display: 'flex', flexDirection: 'row'}}>
          <h4>Package Installed Version : </h4>
          <h3 style={{color: 'blueviolet', marginLeft: 4}}>{item.InstalledVersion}</h3>
        </div>
        <div style={{alignItems: 'center', display: 'flex', flexDirection: 'row'}}>
          <h3>Package Fixed Version : </h3>
          <h4 style={{color: 'blueviolet', marginLeft: 4}}>{item.FixedVersion}</h4>
        </div>
        <div style={{alignItems: 'center', display: 'flex', flexDirection: 'row'}}>
          <h3>Severity : </h3>
          <h4 style={{color: item.Severity === 'HIGH' || item.Severity === 'CRITICAL' ? 'red' : 'green', marginLeft: 4}}>{item.Severity}</h4>
        </div>
      </div>
    ));
  }

  /**
   * Scan Container vulnerabilities handler
   */
  scanContainer() {
    /**
     * Show scan tab
     */
    this.setState({isScanning: true, showScanningInfo: true});
    /**
     * send get request to node/scan
     */
    const {hostname} = window.location;
    const endpoint = `http://${hostname}:4041/api/scan/container?containerName=${this.props?.details?.rank}`;
    fetch(endpoint)
      .then(response => response.json())
      .then((res) => {
        if (res.status) {
          /**
           * Loop over vuls to group them according to their Severities
           */
          if (res.scanReport[0].Vulnerabilities.length > 0) {
            res.scanReport[0].Vulnerabilities.map((item) => {
              if (item.Severity === 'LOW') {
                this.state.scanVulData[0].value += 1;
              } else if (item.Severity === 'MEDIUM') {
                this.state.scanVulData[1].value += 1;
              } else {
                this.state.scanVulData[2].value += 1;
              }
              return this.setState(prevState => ({
                isScanning: false,
                scanVulData: prevState.scanVulData,
                targets: res.scanReport ?? []
              }));
            });
          }
        }
      })
      .catch(() => {
        this.setState({ isScanning: false });
      });
  }

  /**
   * Scan host handler
   */
  scanHost() {
    /**
     * Show scan tab
     */
    this.setState({isScanning: true, showScanningInfo: true});
    /**
     * send get request to node/scan
     */
    const {hostname} = window.location;
    const endpoint = `http://${hostname}:4041/api/scan/host`;
    fetch(endpoint)
      .then(response => response.json())
      .then((res) => {
        if (res.status) {
          /**
           * Loop over vuls to group them according to their Severities
           */
          if (res.scanReport.length > 0) {
            res.scanReport.map(target => (
              target.Vulnerabilities.map((item) => {
                if (item.Severity === 'LOW') {
                  this.state.scanVulData[0].value += 1;
                } else if (item.Severity === 'MEDIUM') {
                  this.state.scanVulData[1].value += 1;
                } else if (item.Severity === 'CRITICAL' || item.Severity === 'HIGH') {
                  this.state.scanVulData[2].value += 1;
                }
                return this.setState(prevState => ({
                  isScanning: false,
                  scanVulData: prevState.scanVulData,
                  targets: res.scanReport
                }));
              })
            ));
          }
        }
        this.setState({ isScanning: false });
      })
      .catch(() => {
      });
  }

  renderTable(table) {
    const { nodeMatches = makeMap() } = this.props;

    if (isGenericTable(table)) {
      return (
        <NodeDetailsGenericTable
          rows={table.rows}
          columns={table.columns}
          matches={nodeMatches.get('tables')}
        />
      );
    } if (isPropertyList(table)) {
      return (
        <NodeDetailsPropertyList
          rows={table.rows}
          controls={table.controls}
          matches={nodeMatches.get('property-lists')}
        />
      );
    }

    log(`Undefined type '${table.type}' for table ${table.id}`);
    return null;
  }

  componentDidUpdate() {
    this.updateTitle();
  }

  updateTitle() {
    setDocumentTitle(this.props.details && this.props.details.label);
  }
}

NodeDetails.propTypes = {
  renderNodeDetailsExtras: PropTypes.func,
};

NodeDetails.defaultProps = {
  renderNodeDetailsExtras: noop,
};

function mapStateToProps(state, ownProps) {
  const currentTopologyId = state.get('currentTopologyId');
  return {
    nodeMatches: state.getIn(['searchNodeMatches', currentTopologyId, ownProps.id]),
    nodes: state.get('nodes'),
    selectedNodeId: state.get('selectedNodeId'),
    transitioning: state.get('pausedAt') !== ownProps.timestamp,
  };
}

export default connect(
  mapStateToProps,
  { clickCloseDetails, clickShowTopologyForNode }
)(NodeDetails);

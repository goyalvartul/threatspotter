import React from 'react';

export default function Header(props) {
  return (
    <div style={{
      alignItems: 'center', backgroundColor: '#FFF', display: 'flex', height: 80, justifyContent: 'flex-start', padding: '0px 30px', width: '100%'
    }}>
      <h2>{props.title || ''}</h2>
    </div>
  );
}

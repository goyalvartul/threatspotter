import React from 'react';
import loader from '../../images/loader.gif';

export default function Loader() {
  return (
    <div style={{
      alignItems: 'center', backgroundColor: '#FFF', display: 'flex', height: '98.4vh', justifyContent: 'center', position: 'absolute', top: 0, width: '87%'
    }}>
      <img
        src={loader}
        alt="Loader"
        style={{height: 180, width: 180}}
      />
    </div>
  );
}

import React from 'react';
import { sortBy } from 'lodash';

import NodeDetailsControlButton from './node-details-control-button';

export default function NodeDetailsControls({
  controls, error, nodeId, pending, topologyId, startScanContainer, onPressHostScanButton
}) {
  let spinnerClassName = 'fa fa-circle-notch fa-spin';

  // Containers scanning
  if (topologyId === 'containers' && controls.length === 5) {
    controls.push({
      human: 'Scan',
      icon: 'fa fa-binoculars',
      id: 'docker_scan_container',
      nodeId: '01d25ad3156e69769992b1e25e140837f3dcdb4c5aece0f411c9062afeff;<container>',
      probeId: '1d1162c0e6d3557a7',
      rank: 8,
    });
  } else if (topologyId === 'hosts' && controls.length === 1) {
    controls.push({
      human: 'Scan-hosts',
      icon: 'fa fa-stethoscope',
      id: 'docker_scan_host',
      nodeId: '01d25ad3156e69769992b1e25e140837f3dcdb4c5aece0f411c9062afeff;<container>',
      probeId: '1d1162c0e6d3557a7',
      rank: 8,
    });
  }

  if (pending) {
    spinnerClassName += ' node-details-controls-spinner';
  } else {
    spinnerClassName += ' node-details-controls-spinner hide';
  }
  return (
    <div className="node-details-controls">
      {error
        && (
        <div className="node-details-controls-error" title={error}>
          <i className="node-details-controls-error-icon fa fa-exclamation-triangle" />
          <span className="node-details-controls-error-messages">{error}</span>
        </div>
        )
      }
      <span className="node-details-controls-buttons">
        {sortBy(controls, 'rank').map(control => (
          <NodeDetailsControlButton
            nodeId={nodeId}
            control={control}
            pending={pending}
            topologyId={topologyId}
            onContainerScanClick={() => startScanContainer()}
            onHostScanClick={() => onPressHostScanButton()}
            key={control.id}
          />
        ))}
      </span>
      {controls && <span title="Applying..." className={spinnerClassName} />}
    </div>
  );
}

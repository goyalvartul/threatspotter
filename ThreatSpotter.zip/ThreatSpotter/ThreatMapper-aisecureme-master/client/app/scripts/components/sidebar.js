import React, { useEffect } from 'react';
import { useHistory, useLocation } from 'react-router-dom';
import { withRouter } from 'react-router';

function Sidebar() {
  const history = useHistory();
  const location = useLocation();
  const className = 'sidebar';
  const isIframe = window !== window.top;
  useEffect(() => {
    console.log('Location');
    console.log(location.pathname);
  });
  return (
    <div className={className}>
      <div className="logo" style={{margin: 25}}>
        {!isIframe
        && (
          <img alt="logo" src={require('../../images/logo.svg')} width="160" />
        )
        }
      </div>
      {
        (location.pathname === '/')
          ? (
            <div
              style={{
                alignItems: 'center', borderRight: '4px solid #C22D2A', cursor: 'pointer', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '10px 8px'
              }}
              onClick={() => { history.push('/#!/state'); }}
            >
              <h4>Overview</h4>
              <i className="fa fa-globe-europe" style={{color: '#C22D2A', marginLeft: 20}} />
            </div>
          ) : (
            <div
              style={{
                alignItems: 'center', cursor: 'pointer', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '10px 8px'
              }}
              onClick={() => { history.push('/#!/state'); }}
            >
              <h4>Overview</h4>
              <i className="fa fa-globe-europe" />
            </div>
          )
      }
      {
        (location.pathname === '/registries')
          ? (
            <div
              style={{
                alignItems: 'center', borderRight: '4px solid #C22D2A', cursor: 'pointer', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '10px 8px',
              }}
              onClick={() => { history.push('/registries'); }}
            >
              <h4>Registries</h4>
              <i className="fa fa-desktop" style={{color: '#C22D2A', marginLeft: 20}} />
            </div>
          ) : (
            <div
              style={{
                alignItems: 'center', cursor: 'pointer', display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '10px 8px',
              }}
              onClick={() => { history.push('/registries'); }}
            >
              <h4>Registries</h4>
              <i className="fa fa-desktop" />
            </div>
          )}
    </div>
  );
}

export default withRouter(Sidebar);

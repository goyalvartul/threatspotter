# Extra code

Useful things that go well with scope.

- Code in this directory must always compile (enforced by CircleCI)
- This directory is ignored for testing but should lint cleanly
- Changes to code in this directory does not need to be PR'd

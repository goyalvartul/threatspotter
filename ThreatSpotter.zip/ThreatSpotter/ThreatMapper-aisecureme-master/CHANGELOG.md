## Release 1.13.1

This release fixes a bug on 'kubernetes describe' operations, where
the probe would spin re-opening a connection to the UI again and again
after the operation had finished.

Also removes some obsolete code which connected to the unsecured local
kubelet port in Kubernetes; please update your configuration to a
single probe to talk to Kubernetes for the whole cluster if you
haven't already. Thanks to @CiMaol for this contribution.

### Bug fixes

- Stop 'kubernetes describe' operations spinning
	[#3784](https://github.com/weaveworks/scope/pull/3784)
- Probe: skip publishing empty reports when publish rate is higher than collection rate
	[#3774](https://github.com/weaveworks/scope/pull/3774)

### Improvements

- Probe no longer talks to local kubelet
	[#3754](https://github.com/weaveworks/scope/pull/3754)
- Track rounding error in multitenant billing calculation
	[#3779](https://github.com/weaveworks/scope/pull/3779)

### Performance

- Multitenant: merge incoming reports in collector, to save IO and query time
	[#3780](https://github.com/weaveworks/scope/pull/3780)
	[#3781](https://github.com/weaveworks/scope/pull/3781)
	[#3782](https://github.com/weaveworks/scope/pull/3782)

### Dependencies

- update html-webpack-plugin to most recent stable
	[#3776](https://github.com/weaveworks/scope/pull/3776)
- downgrade fluent-logger-golang library used in multitenant mode
	[#3772](https://github.com/weaveworks/scope/pull/3772)


## Release 1.13.0

This release brings a few bug-fixes and number of performance
improvements, particularly in reducing the data sent when there are
many socket connections between two endpoints.

The bump in version number reflects a change in wire protocol for this
change in endpoints data, and also a change in the way active controls
are encoded.

Thanks to everyone who contributed to this release: @DarthSett,
@sarataha, @slalwani97 and @qiell.

### Bug fixes

- Remove trailing zeros in large numbers in UI
	[#3760](https://github.com/weaveworks/scope/pull/3760)
- kubernetes: display pod status as "terminating" where appropriate
	[#3729](https://github.com/weaveworks/scope/pull/3729)
- kubernetes: detect more 'pause' containers
	[#3743](https://github.com/weaveworks/scope/pull/3743)
- Improve calculation of usage in multitenant code
	[#3751](https://github.com/weaveworks/scope/pull/3751)
	[#3753](https://github.com/weaveworks/scope/pull/3753)

### Performance improvements

- Elide many connections from/to the same endpoints
	[#3709](https://github.com/weaveworks/scope/pull/3709)
- Remove two specialised data structures; unify with other node data
	[#3714](https://github.com/weaveworks/scope/pull/3714)
	[#3748](https://github.com/weaveworks/scope/pull/3748)
- Simplify some renderers to improve performance
	[#3747](https://github.com/weaveworks/scope/pull/3747)
- Slow down DNS poll interval to reduce network activity
	[#3758](https://github.com/weaveworks/scope/pull/3758)

### Minor improvements

- Add "user-agent" header to http calls from Scope probe
	[#3720](https://github.com/weaveworks/scope/pull/3720)
- Set timestamp and window on each report
	[#3752](https://github.com/weaveworks/scope/pull/3752)
- Add tracing for pipe operations
	[#3745](https://github.com/weaveworks/scope/pull/3745)

### Dependencies updates

- Convert to Go modules
	[#3742](https://github.com/weaveworks/scope/pull/3742)
- Update to Go 1.13.9
	[#3766](https://github.com/weaveworks/scope/pull/3766)
- Go: update weaveworks, prometheus, protobuf, jaeger and aws dependencies
	[#3745](https://github.com/weaveworks/scope/pull/3745)
	[#3756](https://github.com/weaveworks/scope/pull/3756)
- JavaScript: update babel, jest, webpack and other dependencies; dedupe yarn.lock
	[#3733](https://github.com/weaveworks/scope/pull/3733)
	[#3755](https://github.com/weaveworks/scope/pull/3755)
	[#3757](https://github.com/weaveworks/scope/pull/3757)
	[#3763](https://github.com/weaveworks/scope/pull/3763)


## Release 1.12.0

### Highlights

Supports Kubernetes 'v1' object types that are needed for Kubernetes
1.16 and drops support for obsolete 'v1beta' types.
	[#3691](https://github.com/weaveworks/scope/pull/3691)

The serialisation format changes: DNS data was accidentally renamed
'nodes' in release 1.11.6, and this release changes it back to 'DNS'.
	[#3713](https://github.com/weaveworks/scope/pull/3713)

Thanks to everyone who contributed to this release: @bensooraj,
@chandankumar4, @imazik, @oleggator and @qiell.

### Minor improvements

- Allow user to disable plugins via command-line flag.
	[#3703](https://github.com/weaveworks/scope/pull/3703)
- In the UI, replace JSON.stringify with json-stable-stringify
	[#3701](https://github.com/weaveworks/scope/pull/3701)

### Bugs and security fixes

- fix: report http error if /api call fails
	[#3702](https://github.com/weaveworks/scope/pull/3702)
- Fix a rare crash in the ebpf connection tracker by feeding initial connections synchronously on restart.
	[#3712](https://github.com/weaveworks/scope/pull/3712)
- Fix typos in debugging format strings
	[#3695](https://github.com/weaveworks/scope/pull/3695)

### Performance improvements

- handle IP addresses in binary rather than strings
	[#3696](https://github.com/weaveworks/scope/pull/3696)
- In the multitenant app, save IO by keeping rapid-update data outside of the persistent store.
	[#3716](https://github.com/weaveworks/scope/pull/3716)

### Dependencies updates

- Update Go version to 1.13.0
	[#3692](https://github.com/weaveworks/scope/pull/3692)
	[#3698](https://github.com/weaveworks/scope/pull/3698)
- Update google/gopacket library
	[#3606](https://github.com/weaveworks/scope/pull/3606)
- Update NodeJS to 8.12.0 and various javascript libraries
	[#3685](https://github.com/weaveworks/scope/pull/3685)
	[#3690](https://github.com/weaveworks/scope/pull/3690)
	[#3719](https://github.com/weaveworks/scope/pull/3719)
	[#3726](https://github.com/weaveworks/scope/pull/3726)

Build and CI improvements:

- Run UI build container as current user to avoid files being owned by root.
	[#3635](https://github.com/weaveworks/scope/pull/3635)
- Replace SASS files with CSS and JavaScript
	[#3700](https://github.com/weaveworks/scope/pull/3700)
- Remove obsolete -e flag from docker login in CI
	[#3708](https://github.com/weaveworks/scope/pull/3708)
- Fix favicon.ico in UI dev mode
	[#3705](https://github.com/weaveworks/scope/pull/3705)
- Refactor report reading to make the code simpler
	[#3687](https://github.com/weaveworks/scope/pull/3687)
- Don't import fonts when Scope UI is embedded.
	[#3704](https://github.com/weaveworks/scope/pull/3704)


## Release 1.11.6

This is largely a performance improvement release: the biggest change
is that the probe now publishes full reports one in three times; the
rest are deltas which are much smaller hence use less CPU and memory
in the app. [#3677](https://github.com/weaveworks/scope/pull/3677)

Also a new debugging summary function in the app, exposed via http
[#3686](https://github.com/weaveworks/scope/pull/3686)

Some other small performance improvements:

- perf(probe): reduce copying of nodes
	[#3679](https://github.com/weaveworks/scope/pull/3679)
- perf(probe): add 'omitempty' tag to Topology.Nodes
	[#3678](https://github.com/weaveworks/scope/pull/3678)
- perf(probe): update netlink library to bring in performance improvements
	[#3681](https://github.com/weaveworks/scope/pull/3681)
- perf(multitenant): quantise report cache in query side of aws-collector
	[#3671](https://github.com/weaveworks/scope/pull/3671)

Other changes:

- Add tracing spans for rendering to the UI via websocket
	[#3682](https://github.com/weaveworks/scope/pull/3682)
- update some javascript dependencies
	[#3664](https://github.com/weaveworks/scope/pull/3664)
- Upgrades ui-components to version w/ styled-components 4
	[#3670](https://github.com/weaveworks/scope/pull/3670)
	[#3673](https://github.com/weaveworks/scope/pull/3673)
- fix(test-flake): poll for result in TestRegistryDelete() to avoid race
	[#3688](https://github.com/weaveworks/scope/pull/3688)
- refactor: remove old unnecessary controls code
	[#3680](https://github.com/weaveworks/scope/pull/3680)
- Stop render package depending on probe
	[#3675](https://github.com/weaveworks/scope/pull/3675)
- Remove some unused string constants
	[#3674](https://github.com/weaveworks/scope/pull/3674)

## Release 1.11.5

A few small improvements:

- Expose probe metrics to Prometheus, if an http-listen address is given
	[#3600](https://github.com/weaveworks/scope/pull/3600)
- Reduce probe resource usage caused by occasional leaks in probe endpoint reporter
	[#3661](https://github.com/weaveworks/scope/pull/3661)
- Update 'eslint' JavaScript checking tool, and resolve warnings
	[#3643](https://github.com/weaveworks/scope/pull/3643)

## Release 1.11.4

This release contains a few fixes, one of which should improve
resource usage on hosts that have a lot of TCP connections.

- Improve eBPF connection tracker to reduce the number of times it
  restarts and falls back to a less efficient mechanism.
	[#3653](https://github.com/weaveworks/scope/pull/3653)
- Add reporter name to probe error logs. Thanks to @princerachit
	[#3363](https://github.com/weaveworks/scope/pull/3363)
- Defer metrics registration until we need it
	[#3605](https://github.com/weaveworks/scope/pull/3605)
- Remove unused metric SpyDuration
	[#3646](https://github.com/weaveworks/scope/pull/3646)
- Remove quay.io from release script
	[#3657](https://github.com/weaveworks/scope/pull/3657)

## Release 1.11.3

This is a bugfix release, which should improve some cases where
reports get bigger and bigger over time due to Scope not seeing
connections get closed.

- Report the error and restart when something goes wrong in connection tracking
	[#3648](https://github.com/weaveworks/scope/pull/3648)

## Release 1.11.2

Minor update:

 - Updates to JavaScript dependencies, where security issues were reported:
	[#3633](https://github.com/weaveworks/scope/pull/3633)
 - Another fix for Scope not noticing when a container has been destroyed:
	[#3627](https://github.com/weaveworks/scope/pull/3627)

## Release 1.11.1

This release fixes a couple of bugs:

- Sometimes probe would fail to remove its record of a container when it is destroyed
	[#3623](https://github.com/weaveworks/scope/pull/3623)
- Contrast mode was not being reflected in the URL
	[#3617](https://github.com/weaveworks/scope/pull/3617)


## Release 1.11.0

### Highlights

- Add describe control to all Kubernetes resources [#3589](https://github.com/weaveworks/scope/pull/3589)
- Show Kubernetes jobs [#3609](https://github.com/weaveworks/scope/pull/3609)

Thanks to everyone who contributed to this release: @Deepak1100, @SaifRehman, @awolde, @bboreham, @bia, @dholbach, @fbarl, @foot, @guyfedwards, @jrryjcksn, @leavest, @n0rig, @najeal, @paulmorabito, @qiell, @qurname2, @rade, @satyamz, @shindanim, @tiriplicamihai, @tvvignesh, @xrgy.

Special thanks to @qiell and @satyamz for implementing both features!

### Minor improvements

- Conditional report censoring [#3571](https://github.com/weaveworks/scope/pull/3571)
- Add a confirmation dialog for deleting a pod [#3572](https://github.com/weaveworks/scope/pull/3572)
- Add OpenTracing span for report.ReadBinary() [#3598](https://github.com/weaveworks/scope/pull/3598)
- Add metrics for report size and count per tenant [#3599](https://github.com/weaveworks/scope/pull/3599)

### Bugs and security fixes

- Security fixes in dev dependencies [#3578](https://github.com/weaveworks/scope/pull/3578)
- Use Time Travel context when downloading raw reports [#3582](https://github.com/weaveworks/scope/pull/3582)
- Fix bug Chrome 56+ can't prevent default wheel events [#3593](https://github.com/weaveworks/scope/pull/3593)
- Fix dnssnooper probe for multiple CNAMEs [#3566](https://github.com/weaveworks/scope/pull/3566)
- Fix build-pkg script [#3587](https://github.com/weaveworks/scope/pull/3587)

### Dependencies updates

- Upgrade to Webpack 4 [#3580](https://github.com/weaveworks/scope/pull/3580)
- Upgrade client-go version to 10.0.0 [#3588](https://github.com/weaveworks/scope/pull/3588)
- Upgrade ui-components and some of similar dependencies [#3574](https://github.com/weaveworks/scope/pull/3574)
- Remove materialize-css JS dep [#3596](https://github.com/weaveworks/scope/pull/3596)

### Documentation and examples

- The path is actually examples/k8s [#3586](https://github.com/weaveworks/scope/pull/3586)
- Update examples/k8s RBAC permissions [#3595](https://github.com/weaveworks/scope/pull/3595)
- Update example yamls to probe Kubernetes once per cluster [#3569](https://github.com/weaveworks/scope/pull/3569)
- Add CPU and memory requests to example Kubernetes manifests [#3570](https://github.com/weaveworks/scope/pull/3570)
- Extend FAQ with basic auth through environment variables [#3575](https://github.com/weaveworks/scope/pull/3575)

## Release 1.10.2

This release has a security fix, a few bug-fixes and some other minor
improvements.

Special thanks to @arnulfojr, @Akashtic, @AVRahul, @carlosedp, @ycao56
for community contributions!

Security and bug fixes:

- Address vulnerability (CVE-2018-16487) by updating lodash dependency
	[#3568](https://github.com/weaveworks/scope/pull/3568)
- Address vulnerability (CVE-2019-0542) by updating xterm.js dependency
	[#3557](https://github.com/weaveworks/scope/pull/3557)
- Fix missing nodes in Kubernetes Cluster mode
	[#3444](https://github.com/weaveworks/scope/pull/3444)
- Show all connections when one pod has multiple PVCs
	[#3553](https://github.com/weaveworks/scope/pull/3553)
- Fix spurious connection to PVC with same name in different namespace
	[#3530](https://github.com/weaveworks/scope/pull/3530)
- Fix linkage from metrics graph to external monitoring url
	[#3534](https://github.com/weaveworks/scope/pull/3534)
- Fix build mount path in UI unit tests
	[#3558](https://github.com/weaveworks/scope/pull/3558)
- Add extra internal ID on control buttons
	[#3565](https://github.com/weaveworks/scope/pull/3565)

Feature improvements:
- Dynamically expand namespace list if you hover over it
	[#3117](https://github.com/weaveworks/scope/pull/3117)
	[#3562](https://github.com/weaveworks/scope/pull/3562)
- Make Scope's container memory usage number match Docker's
	[#3435](https://github.com/weaveworks/scope/pull/3435)

Build improvements:
- Add ARM64 build
	[#3537](https://github.com/weaveworks/scope/pull/3537)
- Add a CI test to detect the problem which caused release 1.10.0 to fail
	[#3440](https://github.com/weaveworks/scope/pull/3440)
- Update some 3rd-party UI components
	[#3450](https://github.com/weaveworks/scope/pull/3450)
- re-order some code to make it more readable
	[#3551](https://github.com/weaveworks/scope/pull/3551)
- Small performance improvement in rendering Kubernetes volume claims
	[#3445](https://github.com/weaveworks/scope/pull/3445)

Documentation improvements:
- [#3417](https://github.com/weaveworks/scope/pull/3417)
	[#3447](https://github.com/weaveworks/scope/pull/3447)
	[#3448](https://github.com/weaveworks/scope/pull/3448)
	[#3436](https://github.com/weaveworks/scope/pull/3436)
	[#3545](https://github.com/weaveworks/scope/pull/3545)
	[#3546](https://github.com/weaveworks/scope/pull/3546)
	[#3563](https://github.com/weaveworks/scope/pull/3563)

## Release 1.10.1

This is a re-release of 1.10.0 which got hit by an unfortunate build
error.

- UI Build: stop deleting static ui files when building external ui
	[#3439](https://github.com/weaveworks/scope/pull/3439)

## Release 1.10.0

Highlights:

- Add Kubernetes Persistent Volume snapshot and clone operations
	[#3355](https://github.com/weaveworks/scope/pull/3355)

- Kubernetes objects can be reported just once in a cluster, instead
  of reporting the same data from every node.
	[#3274](https://github.com/weaveworks/scope/pull/3274)
	[#3419](https://github.com/weaveworks/scope/pull/3419)
	[#3432](https://github.com/weaveworks/scope/pull/3432)

- App now supports http basic auth
	[#3393](https://github.com/weaveworks/scope/pull/3393)

Some changes (#3266, #3272) were made to the wire protocol, which
means new probes are not compatible with an older app.

Thanks for contributions from @Akash4927, @akshatnitd, @bhavin192,
@hexmind, @gfeun, @gotjosh, @gruebel, @hexmind, @jgsqware, @ltachet,
@muthumalla, @rvrvrv, @satyamz, @ScottBrenner, @ssiddhantsharma,
@visualapps, @WhiteHatTux, @ycao56, @Xivolkar - some of these came via
[Hacktoberfest](https://hacktoberfest.digitalocean.com/).

Performance:

- Probe: use netlink to talk to conntrack
	[#3298](https://github.com/weaveworks/scope/pull/3298)
- Remove First and Last data members from Metrics structs
	[#3266](https://github.com/weaveworks/scope/pull/3266)
- Remove old 'Controls' field which was replaced two years ago
	[#3272](https://github.com/weaveworks/scope/pull/3272)
- Probe: Don't report dead or defunct processes
	[#3379](https://github.com/weaveworks/scope/pull/3379)
- Simplify fetch of IP addresses in a namespace
	[#3335](https://github.com/weaveworks/scope/pull/3335)
- Discard pod updates for other nodes
	[#3391](https://github.com/weaveworks/scope/pull/3391)
- Probe: Rate-limit report publishing
	[#3386](https://github.com/weaveworks/scope/pull/3386)
- In multitenant app, drop all nodes for big topologies
	[#3384](https://github.com/weaveworks/scope/pull/3384)

Bug fixes and minor improvements:

- Initial Container Runtime Interface (CRI) support
	[#3275](https://github.com/weaveworks/scope/pull/3275)
	[#3305](https://github.com/weaveworks/scope/pull/3305)
	[#3308](https://github.com/weaveworks/scope/pull/3308)
	[#3392](https://github.com/weaveworks/scope/pull/3392)
	[#3364](https://github.com/weaveworks/scope/pull/3364)
- Add storage driver name to Persistent Volume
	[#3260](https://github.com/weaveworks/scope/pull/3260)
- Fix WithLatests() fixup on duplicate keys
	[#3281](https://github.com/weaveworks/scope/pull/3281)
- Add EKS variant of 'pause container'
	[#3421](https://github.com/weaveworks/scope/pull/3421)
- Add Opentracing (Jaeger) distributed tracing for profiling the app
	[#3307](https://github.com/weaveworks/scope/pull/3307)
	[#3380](https://github.com/weaveworks/scope/pull/3380)
	[#3383](https://github.com/weaveworks/scope/pull/3383)
	[#3325](https://github.com/weaveworks/scope/pull/3325)
- app: update stopped container message
	[#3396](https://github.com/weaveworks/scope/pull/3396)
- Example Kubernetes yaml files: fix typos and work with newer Kubernetes
	[#3403](https://github.com/weaveworks/scope/pull/3403)
- Example Kubernetes yaml files: add support for PodSecurityPolicy
	[#3354](https://github.com/weaveworks/scope/pull/3354)
- Example Kubernetes yaml files: add rules in cluster role for storage components
	[#3290](https://github.com/weaveworks/scope/pull/3290)
- rename 'storagesheet' to 'sheet' in reports
	[#3323](https://github.com/weaveworks/scope/pull/3323)
	[#3324](https://github.com/weaveworks/scope/pull/3324)
- Check container is running before trying to open its namespace
	[#3279](https://github.com/weaveworks/scope/pull/3279)

User Interface

- Upgrade to font-awesome 5 and new icons
	[#3426](https://github.com/weaveworks/scope/pull/3426)
- replace share icon with sitemap on graph button
	[#3387](https://github.com/weaveworks/scope/pull/3387)
- Bump ui-components version
	[#3282](https://github.com/weaveworks/scope/pull/3282)
	[#3431](https://github.com/weaveworks/scope/pull/3431)
- Use GraphNode component from ui-components library
	[#3262](https://github.com/weaveworks/scope/pull/3262)
- Make header semitransparent
	[#3294](https://github.com/weaveworks/scope/pull/3294)
- Fix broken styling of terminal in contrast mode
	[#3347](https://github.com/weaveworks/scope/pull/3347)
- Add onRouteChange hook to Scope app
	[#3349](https://github.com/weaveworks/scope/pull/3349)
- Stop two Scope instances on the same domain from changing each other's history
	[#3326](https://github.com/weaveworks/scope/pull/3326)
- Use new Search component from ui-components repo
	[#3337](https://github.com/weaveworks/scope/pull/3337)
- Update localStorage with Scope state also on initial router hook
	[#3315](https://github.com/weaveworks/scope/pull/3315)

Build and test improvements

- Remove weaveutil and weave from Dockerfile.cloud-agent
	[#3369](https://github.com/weaveworks/scope/pull/3369)
- Build on Power CPU architecture.
	[#3231](https://github.com/weaveworks/scope/pull/3231)
- build: Fix import for golint which has moved
	[#3389](https://github.com/weaveworks/scope/pull/3389)
- Sleep to stop TestRegistryDelete() failing
	[#3334](https://github.com/weaveworks/scope/pull/3334)
- Fix vendoring of ugorji/go
	[#3280](https://github.com/weaveworks/scope/pull/3280)
- Update version of sirupsen/logrus
	[#3276](https://github.com/weaveworks/scope/pull/3276)
	[#3277](https://github.com/weaveworks/scope/pull/3277)
- Upgrade Kubernetes client-go version to 8.0.0
	[#3329](https://github.com/weaveworks/scope/pull/3329)
- Update lodash dependency to remove security warning
	[#3310](https://github.com/weaveworks/scope/pull/3310)
- Rework UI build to improve caching and fix packaging issue
	[#3353](https://github.com/weaveworks/scope/pull/3353)
	[#3356](https://github.com/weaveworks/scope/pull/3356)
	[#3360](https://github.com/weaveworks/scope/pull/3360)
	[#3382](https://github.com/weaveworks/scope/pull/3382)
- Update the 'tools' subdirectory
	[#3311](https://github.com/weaveworks/scope/pull/3311)
	[#3312](https://github.com/weaveworks/scope/pull/3312)
- Clean up Dockerfiles
	[#3411](https://github.com/weaveworks/scope/pull/3411)
- update vendored copy of tcptracer-bpf for licence reasons
	[#3336](https://github.com/weaveworks/scope/pull/3336)
- vendor: update gopkg.in/yaml.v2 to latest upstream
	[#3317](https://github.com/weaveworks/scope/pull/3317)
- Create bpf stop file differently, in integration test
	[#3332](https://github.com/weaveworks/scope/pull/3332)
- Move to CircleCI 2.0
	[#3333](https://github.com/weaveworks/scope/pull/3333)


## Release 1.9.1

Highlights:

Scope now displays Kubernetes Storage (PersistentVolume and
PersistentVolumeClaim) information on the Pods view.
	[#3132](https://github.com/weaveworks/scope/pull/3132)

Thanks to @satyamz and all at OpenEBS for this contribution!

Also thanks for the example Kubernetes manifests from @tasdikrahman.

Bug fixes and minor improvements:

- Fix 'Unmanaged' nodes showing despite 'Hide Umanaged' filter
	[#3189](https://github.com/weaveworks/scope/pull/3189)
- Fixes monospace font overlapping in terminal+linux
	[#3248](https://github.com/weaveworks/scope/pull/3248)
- make process-by-name topology show something
	[#3208](https://github.com/weaveworks/scope/pull/3208)
- Use the default value for a TopologyOption if omitted
	[#3165](https://github.com/weaveworks/scope/pull/3165)
- Adjusted terminal character width/height estimation
	[#3179](https://github.com/weaveworks/scope/pull/3179)
- Fix pause image detection for Kubernetes 1.10
	[#3183](https://github.com/weaveworks/scope/pull/3183)
- ebpf: update check for known faulty Ubuntu kernels
	[#3188](https://github.com/weaveworks/scope/pull/3188)
- Add option to print probe reports to stdout, for debugging
	[#3204](https://github.com/weaveworks/scope/pull/3204)
- Fix querier panic introduced in #3143
	[#3156](https://github.com/weaveworks/scope/pull/3156)
- Fix rare crash in filter function
	[#3232](https://github.com/weaveworks/scope/pull/3232)
- Probe: fix error message to name the correct flag probe.proc.spy
	[#3216](https://github.com/weaveworks/scope/pull/3216)
- Remove ProcessWithContainerNameRenderer, it wasn't working
	[#3263](https://github.com/weaveworks/scope/pull/3263)
- Close terminal window on exit; update xterm to version 3.3.0
	[#3172](https://github.com/weaveworks/scope/pull/3172)
- Add org.opencontainers.image.* labels to Dockerfiles
	[#3171](https://github.com/weaveworks/scope/pull/3171)
- Make table header line up with columns when scrollbar appears
	[#3169](https://github.com/weaveworks/scope/pull/3169)
- Add command-line flag to set SQS RPC timeout
	[#3157](https://github.com/weaveworks/scope/pull/3157)

Performance:

A number of small performance improvements have gone into this
release, reducing memory and CPU usage.

- Probe: remove backwards-compatibility code when publishing reports
	[#3215](https://github.com/weaveworks/scope/pull/3215)
- Optimise Node.WithLatests()
	[#3268](https://github.com/weaveworks/scope/pull/3268)
- Optimise WithParents() when there is only one parent
	[#3269](https://github.com/weaveworks/scope/pull/3269)
- Re-use gzip writers in a pool
	[#3267](https://github.com/weaveworks/scope/pull/3267)
- Optimise merge where one side is a subset of the other
	[#3253](https://github.com/weaveworks/scope/pull/3253)
- Use a buffer pool in report.ReadBinary() to reduce garbage-collection
	[#3255](https://github.com/weaveworks/scope/pull/3255)
- Faster report merging through mutating objects
	[#3236](https://github.com/weaveworks/scope/pull/3236)
- Faster path to check an IP address against known networks
	[#3142](https://github.com/weaveworks/scope/pull/3142)
- Skip pods with no IP addresses when rendering network connections
	[#3201](https://github.com/weaveworks/scope/pull/3201)
- Fetch container IPs directly from the namespace instead of calling 'weave ps'
	[#3207](https://github.com/weaveworks/scope/pull/3207)

UI:

A number of changes adjusting fonts and colors, and standardising the
UI through the use of a theme.

- Update fonts - use Proxima Nova as a default font instead of Roboto.
	[#3177](https://github.com/weaveworks/scope/pull/3177)
- Adjust font sizes
	[#3181](https://github.com/weaveworks/scope/pull/3181)
- Update gray theme colors
	[#3234](https://github.com/weaveworks/scope/pull/3234)
- Use new accent theme colors
	[#3230](https://github.com/weaveworks/scope/pull/3230)
- Use new purple theme colors
	[#3229](https://github.com/weaveworks/scope/pull/3229)
- Use new theme gray colors
	[#3227](https://github.com/weaveworks/scope/pull/3227)
- Stop using dropped theme colors
	[#3148](https://github.com/weaveworks/scope/pull/3148)
- Merge neutral theme colors
	[#3146](https://github.com/weaveworks/scope/pull/3146)
- Slightly lightening background to match the rest of WeaveCloud
	[#3206](https://github.com/weaveworks/scope/pull/3206)
- Sentence cased text everywhere
	[#3166](https://github.com/weaveworks/scope/pull/3166)
- Show image tag more clearly in node details
	[#3173](https://github.com/weaveworks/scope/pull/3173)
- Standardise border radius
	[#3170](https://github.com/weaveworks/scope/pull/3170)
- Enforce theme font sizes
	[#3167](https://github.com/weaveworks/scope/pull/3167)
- Use only z-index values from the theme
	[#3159](https://github.com/weaveworks/scope/pull/3159)

Weave Cloud specific

As well as some bug-fixes, refactoring of places where the integration
of Scope into the hosted Weave Cloud UI complicated the code.

- Correct api.getFluxImages usage
	[#3233](https://github.com/weaveworks/scope/pull/3233)
- Show deployments in Time Travel
	[#3222](https://github.com/weaveworks/scope/pull/3222)
- Separate API endpoint namespace from URL path part
	[#3221](https://github.com/weaveworks/scope/pull/3221)
- Fix scope report download URL in Weave Cloud
	[#3213](https://github.com/weaveworks/scope/pull/3213)
- Use common TimestampTag component
	[#3195](https://github.com/weaveworks/scope/pull/3195)
- Change URL resolution to accommodate Weave Cloud paths
	[#3175](https://github.com/weaveworks/scope/pull/3175)
- Support rendering node details extras
	[#3244](https://github.com/weaveworks/scope/pull/3244)
- Support TimeTravel injection
	[#3239](https://github.com/weaveworks/scope/pull/3239)


## Release 1.9.0

Highlights:

- Change in behaviour of table data: Docker labels are now sent in
full, while Docker environment variables are not reported by default
- Plugins can now render http links and show controls on more objects

New plugin features:

- Render http links in tables
	[#3105](https://github.com/weaveworks/scope/pull/3105)
- Support plugin controls in K8s Service, DaemonSet, StatefulSet, Cronjob.
	[#3110](https://github.com/weaveworks/scope/pull/3110)

Bug fixes and minor improvements:

- Work around Ubuntu kernel crash
	[#3141](https://github.com/weaveworks/scope/pull/3141)
- Stop truncating tables; disable reporting Docker env vars by default
	[#3139](https://github.com/weaveworks/scope/pull/3139)
- Don't show Failed pods
	[#3126](https://github.com/weaveworks/scope/pull/3126)
- Make scope start with Docker for Mac again.
	[#3140](https://github.com/weaveworks/scope/pull/3140)
- Fix browser history when deep linking into node details with time context
	[#3134](https://github.com/weaveworks/scope/pull/3134)
- Move to more consistent colour theme
	[#3116](https://github.com/weaveworks/scope/pull/3116)
	[#3124](https://github.com/weaveworks/scope/pull/3124)
	[#3136](https://github.com/weaveworks/scope/pull/3136)
- Fix format string only used in debugging
	[#3129](https://github.com/weaveworks/scope/pull/3129)
- Fix docs for OpenShift installation
	[#3128](https://github.com/weaveworks/scope/pull/3128)

Performance:

-  Use unsafe merge in joinResults.addChildAndChildren()
	[#3143](https://github.com/weaveworks/scope/pull/3143)
- Use single-owner code path to accumulate children when rendering
	[#3138](https://github.com/weaveworks/scope/pull/3138)
- Simplify Map.Render()
	[#3135](https://github.com/weaveworks/scope/pull/3135)
- Let probe send smaller 'shortcut' reports to update the UI faster
	[#3121](https://github.com/weaveworks/scope/pull/3121)


## Release 1.8.0

Highlights:
- Many performance improvements
- A change in the wire protocol (see #3061 below - the new app is
  compatible with older probes but not vice-versa)

New features and enhancements:

- Add Kubernetes service type and ports to Services display
	[#3090](https://github.com/weaveworks/scope/pull/3090)

Bug fixes and minor improvements:

- revamp install instructions
	[#3052](https://github.com/weaveworks/scope/pull/3052)
- Fix 'Unmanaged' nodes showing despite 'Hide Umanaged' filter
	[#3097](https://github.com/weaveworks/scope/pull/3097)
- Remove large gap in between header and table
	[#3066](https://github.com/weaveworks/scope/pull/3066)
- Blank out value on LatestMap decode insert
	[#3095](https://github.com/weaveworks/scope/pull/3095)
- refactor: don't return receiver in Topology.AddNode()
	[#3075](https://github.com/weaveworks/scope/pull/3075)
- Remove unused process tree function GetChildren()
	[#3094](https://github.com/weaveworks/scope/pull/3094)

Performance improvements:

- Move DNS name mapping from endpoint to report
	[#3061](https://github.com/weaveworks/scope/pull/3061)
- Enable setting to stop requesting pod list from kubelet, via environment variable
	[#3077](https://github.com/weaveworks/scope/pull/3077)
- Exclude null entries for networks on container nodes in probe report
	[#3091](https://github.com/weaveworks/scope/pull/3091)
- Remove flag -probe.kubernetes.interval and stop re-syncing Kubernetes data
	[#3080](https://github.com/weaveworks/scope/pull/3080)
- Optimise processTopology()
	[#3074](https://github.com/weaveworks/scope/pull/3074)
- More efficient docker Tagger
	[#3093](https://github.com/weaveworks/scope/pull/3093)
- Add topology.ReplaceNode() for efficiency
	[#3073](https://github.com/weaveworks/scope/pull/3073)
- Set 'omitempty' on Node Adjacency
	[#3062](https://github.com/weaveworks/scope/pull/3062)

Security:

- Bump JavaScript dependencies to pick up fix for security advisory
	[#3102](https://github.com/weaveworks/scope/pull/3102)

Build and test:

- Add a test that checks if reports with data round-trip
	[#2399](https://github.com/weaveworks/scope/pull/2399)
- Save generated source code as a CI artifact, in case it is needed
  for troubleshooting.
	[#3056](https://github.com/weaveworks/scope/pull/3056)

Weave Cloud related changes:

- Disable detail panel link if monitoring is not available.
	[#3070](https://github.com/weaveworks/scope/pull/3070)
	[#3072](https://github.com/weaveworks/scope/pull/3072)
- Add (cloud.)weave.works to the list of known services
	[#3084](https://github.com/weaveworks/scope/pull/3084)
- Only modify document title if running standalone
	[#3071](https://github.com/weaveworks/scope/pull/3071)
- Fixes bug showing "container image status" on all resource types
	[#3054](https://github.com/weaveworks/scope/pull/3054)
- Changes relating to Guided Tours
	[#3068](https://github.com/weaveworks/scope/pull/3068)
	[#3088](https://github.com/weaveworks/scope/pull/3088)
- Show Time Travel at all times in Weave Cloud
	[#3065](https://github.com/weaveworks/scope/pull/3065)
- Update service cpu/mem link
	[#3060](https://github.com/weaveworks/scope/pull/3060)


## Release 1.7.3

Bug fixes and minor improvements:
- Fixes the problem where, if the api server was unreachable at start up, no kubernetes resources would be reported.
	[#3050](https://github.com/weaveworks/scope/pull/3050)


## Release 1.7.2

Highlights:
- eBPF tracker working on GKE: this makes connection tracking more efficient and accurate

New features and enhancements:
- vendor: bump tcptracer-bpf
	[#3042](https://github.com/weaveworks/scope/pull/3042)

Bug fixes and minor improvements:
- Close terminal pipe, when closing the pod panel
	[#3045](https://github.com/weaveworks/scope/pull/3045)
- Fetch cronjobs from 'batch/v1beta1'. This fixes a bug which caused CronJobs in recent k8s not to appear in Scope.
	[#3044](https://github.com/weaveworks/scope/pull/3044)

Documentation:
- Update install instructions to use weave namespace
	[#3041](https://github.com/weaveworks/scope/pull/3041)


## Release 1.7.1

Highlights:
- A bug was introduced in 1.7.0 when closing the pod log terminal panel that causes the probe to spin,
  therefore saturating a cpu. This has been fixed in #3034.
- Fix issue that would cause the probe not to report certain kubernetes resources if, at start up,
  it failed to successfully connect to kubernetes' API.

Bug fixes and minor improvements:
- logReadCloser: ensure EOF after `Close()`
	[#3034](https://github.com/weaveworks/scope/pull/3034)
- Check if k8s resources are supported in `runReflectorUntil`
	[#3037](https://github.com/weaveworks/scope/pull/3037)
- Stop page router on App unmount
	[#3025](https://github.com/weaveworks/scope/pull/3025)
- client: Fix uptime sort in table view
	[#3038](https://github.com/weaveworks/scope/pull/3038)

Internal improvements and cleanup:
- Remove default values from URL state hash
	[#3030](https://github.com/weaveworks/scope/pull/3030)
- Correctly handle Time Travel resuming in Monitor
	[#3028](https://github.com/weaveworks/scope/pull/3028)
- Change pausedAt format from moment() back to ISO string
	[#3036](https://github.com/weaveworks/scope/pull/3036)


## Release 1.7.0

Highlights:
- Displaying pod logs now shows all container logs with each line prefixed by `[containerName]`.
  Previously, the same view would fail if the pod had multiple containers.
- Show all Kubernetes namespaces, including empty ones.
- Various small improvements and performance work

New features and enhancements:
- Reading pod logs returns all container logs
	[#3013](https://github.com/weaveworks/scope/pull/3013)
- Probe reports namespaces
	[#2985](https://github.com/weaveworks/scope/pull/2985)
- show unconnected processes
	[#3009](https://github.com/weaveworks/scope/pull/3009)

Bug fixes and minor improvements:
- Set a timeout to Terminal animation
	[#3021](https://github.com/weaveworks/scope/pull/3021)
- 'updateKubeFilters` returns early if there are no namespaces
	[#3017](https://github.com/weaveworks/scope/pull/3017)
- don't map image adjacencies to hosts
	[#2997](https://github.com/weaveworks/scope/pull/2997)
- cope with one->many topology mappings
	[#2996](https://github.com/weaveworks/scope/pull/2996)
- Tag images at build time
	[#2987](https://github.com/weaveworks/scope/pull/2987)
- don't exclude NATed connections in mapping to processes
	[#2978](https://github.com/weaveworks/scope/pull/2978)

Internal improvements and cleanup:
- refactor: extract common code in endpoint mapping
	[#3016](https://github.com/weaveworks/scope/pull/3016)
- refactor: make PropagateSingleMetrics a renderer
	[#3008](https://github.com/weaveworks/scope/pull/3008)
- refactor: move RenderContext where it belongs
	[#3005](https://github.com/weaveworks/scope/pull/3005)
- render sensible labels for nodes with little/no metadata
	[#2998](https://github.com/weaveworks/scope/pull/2998)
- refactor: banish TheInternet
	[#3003](https://github.com/weaveworks/scope/pull/3003)
- benchmark report summarization
	[#3000](https://github.com/weaveworks/scope/pull/3000)
- refactor: inline summarisation of metadata, metrics, tables
	[#2999](https://github.com/weaveworks/scope/pull/2999)
- Upgrade Go to 1.9.2
	[#2993](https://github.com/weaveworks/scope/pull/2993)
- simplify `joinResults`
	[#2994](https://github.com/weaveworks/scope/pull/2994)
- Suggest how to disable weave errors and warnings
	[#2990](https://github.com/weaveworks/scope/pull/2990)
- refactor: drop networks from render.MapFunc
	[#2991](https://github.com/weaveworks/scope/pull/2991)

Performance improvements:
- remove Node.Edges
	[#2992](https://github.com/weaveworks/scope/pull/2992)
- remove unnecessary metadata propagation
	[#3007](https://github.com/weaveworks/scope/pull/3007)
- permit setting `probe.kubernetes.interval` to 0
	[#3012](https://github.com/weaveworks/scope/pull/3012)
- Stop fetching ReplicaSets and ReplicationControllers
	[#3014](https://github.com/weaveworks/scope/pull/3014)
- optimisation: pre-allocate, and fewer slices during summarisation
	[#3002](https://github.com/weaveworks/scope/pull/3002)
- make `Report.Topology(name)` fast
	[#3001](https://github.com/weaveworks/scope/pull/3001)

Weave Cloud related changes:
- Bump ui-components to v0.4.18
	[#3019](https://github.com/weaveworks/scope/pull/3019)
- Simplifying backgrounds to match lightgray in service-ui and ui-compo…
	[#3011](https://github.com/weaveworks/scope/pull/3011)


## Release 1.6.7

This is a minor patch release.

Internal improvements and cleanup:
- Upgrade weaveworks-ui-components to 0.3.10
	[#2980](https://github.com/weaveworks/scope/pull/2980)
- Lock styled-components version and upgrade ui-components
	[#2976](https://github.com/weaveworks/scope/pull/2976)
- don't embed docker binary
	[#2977](https://github.com/weaveworks/scope/pull/2977)
- bump embedded Weave Net version to 2.1.3
	[#2975](https://github.com/weaveworks/scope/pull/2975)
- do not report allocations in benchmarks
	[#2964](https://github.com/weaveworks/scope/pull/2964)

Performance improvements:
- "Intern" map keys
	[#2865](https://github.com/weaveworks/scope/pull/2865)
- Upgrade reports before caching
	[#2979](https://github.com/weaveworks/scope/pull/2979)
- report.Upgrade() add deployments to pods as parent
	[#2973](https://github.com/weaveworks/scope/pull/2973)

Weave Cloud related changes:
- probe: Use an absolute FQDN for cloud.weave.works by default
	[#2971](https://github.com/weaveworks/scope/pull/2971)
- Bump ui-components to include decomposed Time Travel
	[#2986](https://github.com/weaveworks/scope/pull/2986)
- cheap probe connectedness api endpoint
	[#2983](https://github.com/weaveworks/scope/pull/2983)


## Release 1.6.6

This is a minor patch release.

New features and enhancements:
- Upgrade to React 16
	[#2929](https://github.com/weaveworks/scope/pull/2929)
- Humanize reported durations
	[#2915](https://github.com/weaveworks/scope/pull/2915)
- Use firstSeenConnectAt for beginning of availability period in Time Travel
	[#2912](https://github.com/weaveworks/scope/pull/2912)
- Flat background instead of gradient
	[#2886](https://github.com/weaveworks/scope/pull/2886)

Bug fixes and minor improvements:
- fix incorrect reporting of replicaset DesiredReplicas
	[#2955](https://github.com/weaveworks/scope/pull/2955)
- filter internet adjacencies
	[#2954](https://github.com/weaveworks/scope/pull/2954)
- filter out unconnected pseudo nodes just once, at the end
	[#2951](https://github.com/weaveworks/scope/pull/2951)
- Correctly show whether there are new images or not.
	[#2948](https://github.com/weaveworks/scope/pull/2948)
- Fix undefined image bug
	[#2934](https://github.com/weaveworks/scope/pull/2934)
- Use timestamp in URL
	[#2919](https://github.com/weaveworks/scope/pull/2919)
- Fix incorrect image status text bug
	[#2935](https://github.com/weaveworks/scope/pull/2935)
- Don't de-reference pointers from ECS without checking
	[#2918](https://github.com/weaveworks/scope/pull/2918)
- MAINTAINER is deprecated, now using LABEL
	[#2916](https://github.com/weaveworks/scope/pull/2916)
- Try to prevent zooming NaN errors
	[#2906](https://github.com/weaveworks/scope/pull/2906)
- Check whether tableContent ref is present
	[#2907](https://github.com/weaveworks/scope/pull/2907)
- Use TimeTravel from ui-components repo
	[#2903](https://github.com/weaveworks/scope/pull/2903)
- docker: Close pipe when the docker API call fails
	[#2894](https://github.com/weaveworks/scope/pull/2894)
- terminal: Fix Caculated typo
	[#2897](https://github.com/weaveworks/scope/pull/2897)
- Fix golint if/else
	[#2892](https://github.com/weaveworks/scope/pull/2892)
- Make Time Travel a modular component
	[#2888](https://github.com/weaveworks/scope/pull/2888)
- Use a context sensitive route for the popped out terminal.html
	[#2882](https://github.com/weaveworks/scope/pull/2882)
- Fixes images in details-panel after service -> resources change
	[#2885](https://github.com/weaveworks/scope/pull/2885)
- Fixes "Save as svg" functionality.
	[#2883](https://github.com/weaveworks/scope/pull/2883)
- tracking: Fix in-flight collision of two related PRs
	[#2867](https://github.com/weaveworks/scope/pull/2867)
- lint: Fix 2 sites failing a recently introduced golint check
	[#2868](https://github.com/weaveworks/scope/pull/2868)
- Continue processing reports if billing fails
	[#2860](https://github.com/weaveworks/scope/pull/2860)

Documentation:
- Add godoc to README
	[#2891](https://github.com/weaveworks/scope/pull/2891)
- Bump license copyright year to 2017
	[#2873](https://github.com/weaveworks/scope/pull/2873)

Internal improvements and cleanup:
- make render.ResetCache() reset all caches
	[#2949](https://github.com/weaveworks/scope/pull/2949)
- Decorators, begone!
	[#2947](https://github.com/weaveworks/scope/pull/2947)
- Expand the app's k8s namespace calculation
	[#2946](https://github.com/weaveworks/scope/pull/2946)
- pass render filters and maps by value rather than reference
	[#2944](https://github.com/weaveworks/scope/pull/2944)
- Remove optional dependencies
	[#2930](https://github.com/weaveworks/scope/pull/2930)
- remove unused memoisation
	[#2924](https://github.com/weaveworks/scope/pull/2924)
- Simplify Utsname string conversion
	[#2917](https://github.com/weaveworks/scope/pull/2917)
- vendoring: Update gopacket to latest master
	[#2911](https://github.com/weaveworks/scope/pull/2911)
- Update minor node dependencies
	[#2900](https://github.com/weaveworks/scope/pull/2900)
- Update eslint dependencies
	[#2896](https://github.com/weaveworks/scope/pull/2896)
- Get rid of react-tooltip dependency
	[#2871](https://github.com/weaveworks/scope/pull/2871)
- Update ugorji/go/codec
	[#2863](https://github.com/weaveworks/scope/pull/2863)

Performance improvements:
- make report upgrading fast when it's a no-op
	[#2965](https://github.com/weaveworks/scope/pull/2965)
- Remove struct wrapping LatestMap
	[#2961](https://github.com/weaveworks/scope/pull/2961)
- Stop reporting ReplicaSets
	[#2957](https://github.com/weaveworks/scope/pull/2957)
- optimisation: allocate less memory in LatestMap merging
	[#2956](https://github.com/weaveworks/scope/pull/2956)
- Decode reports from a byte buffer
	[#2386](https://github.com/weaveworks/scope/pull/2386)
- optimisation: faster knownServiceCache
	[#2952](https://github.com/weaveworks/scope/pull/2952)
- optimisation: make Memoise(Memoise(...)) only memoise once
	[#2950](https://github.com/weaveworks/scope/pull/2950)
- Rewrite more Map-Reduces as Renderers to save garbage
	[#2938](https://github.com/weaveworks/scope/pull/2938)
- Parsing optimisations
	[#2937](https://github.com/weaveworks/scope/pull/2937)
- produce stats as part of rendering
	[#2926](https://github.com/weaveworks/scope/pull/2926)
- Optimisation: replace three map-reduces with Renderers
	[#2920](https://github.com/weaveworks/scope/pull/2920)
- Avoid object creation when scanning DNS names
	[#2921](https://github.com/weaveworks/scope/pull/2921)
- Re-implement LatestMap as a sorted slice for better performance
	[#2870](https://github.com/weaveworks/scope/pull/2870)
- Small memory-allocation reduction
	[#2872](https://github.com/weaveworks/scope/pull/2872)

Weave Cloud related changes:
- tracking: Use segment for tracking
	[#2861](https://github.com/weaveworks/scope/pull/2861)
- tracking: Add Mixpanel event on Control clicks
	[#2857](https://github.com/weaveworks/scope/pull/2857)

## Release 1.6.5

This is a minor patch release.

New features and enhancements:
- Add ECS Cluster Region option
	[#2854](https://github.com/weaveworks/scope/pull/2854)

Bug fixes and minor improvements:
- Fix edges disappearing in graph mode
	[#2851](https://github.com/weaveworks/scope/pull/2851)
- Fixed header elements responsiveness
	[#2839](https://github.com/weaveworks/scope/pull/2839)

Documentation:
- Update ECS AMI docs
	[#2846](https://github.com/weaveworks/scope/pull/2846)
- More precise compose instructions
	[#2843](https://github.com/weaveworks/scope/pull/2843)

Internal improvements and cleanup:
- Fix test broken by #2854
	[#2856](https://github.com/weaveworks/scope/pull/2856)
- Fix circle.yml syntax
	[#2841](https://github.com/weaveworks/scope/pull/2841)
- make circleci ui-upload unconditional
	[#2837](https://github.com/weaveworks/scope/pull/2837)

Weave Cloud related changes:
- AWS connection keep-alive
	[#2852](https://github.com/weaveworks/scope/pull/2852)

## Release 1.6.4

Re-release of 1.6.3 for which there were some problems publishing Docker images.

Documentation:
- Fix phrasing in readme
	[#2836](https://github.com/weaveworks/scope/pull/2836)


## Release 1.6.3

This is a minor patch release.

New features and enhancements:
- Make Scope's URL message more precise
	[#2810](https://github.com/weaveworks/scope/pull/2810)
- Balance timeline zooming sensitivity between Firefox and Chrome
	[#2788](https://github.com/weaveworks/scope/pull/2788)
- Adjust timeline zoom sensitivity on Firefox
	[#2777](https://github.com/weaveworks/scope/pull/2777)
- run a normal (rather than login) shell in containers
	[#2781](https://github.com/weaveworks/scope/pull/2781)
- Add pod restart count to details pane
	[#2761](https://github.com/weaveworks/scope/pull/2761)

Performance improvements:
- Make nodes graph animations a bit faster
	[#2803](https://github.com/weaveworks/scope/pull/2803)
- Improve Firefox performance
	[#2795](https://github.com/weaveworks/scope/pull/2795)
- synthesise k8s service network from service IPs
	[#2779](https://github.com/weaveworks/scope/pull/2779)
	[#2806](https://github.com/weaveworks/scope/pull/2806)

Bug fixes and minor improvements:
- restart eBPF tracking on error
	[#2735](https://github.com/weaveworks/scope/pull/2735)
- Fix processes/hosts table not appearing
	[#2824](https://github.com/weaveworks/scope/pull/2824)
- Fix query filters by adding namespaces and using docker container name
	[#2819](https://github.com/weaveworks/scope/pull/2819)
- Remove whitespace from empty connection lists
	[#2811](https://github.com/weaveworks/scope/pull/2811)
- Fix rendering of exported SVG
	[#2794](https://github.com/weaveworks/scope/pull/2794)
- k8s probe: Fix a panic (nil pointer deref) when a cronjob has never been scheduled
	[#2785](https://github.com/weaveworks/scope/pull/2785)

Documentation:
- remove extra indent on note
	[#2816](https://github.com/weaveworks/scope/pull/2816)

Internal improvements and cleanup:
- Use Node 8.4 for builds
	[#2830](https://github.com/weaveworks/scope/pull/2830)
- refactor: reduce duplication in links_test
	[#2820](https://github.com/weaveworks/scope/pull/2820)
- add 'realclean' make target to clear out container images
	[#2771](https://github.com/weaveworks/scope/pull/2771)
- get rid of endpoint type indicators
	[#2772](https://github.com/weaveworks/scope/pull/2772)
- rename 'report_persistence' capability to 'historic_reports'
	[#2774](https://github.com/weaveworks/scope/pull/2774)
- Add test for pods number not updating
	[#2741](https://github.com/weaveworks/scope/pull/2741)
- refactor: remove duplication
	[#2765](https://github.com/weaveworks/scope/pull/2765)
- push release images to quay.io
	[#2763](https://github.com/weaveworks/scope/pull/2763)

Weave Cloud related changes:
- Link scope-ui graphs clickable to prometheus queries
	[#2664](https://github.com/weaveworks/scope/pull/2664)
- scope/cortex: fix typo in query filter
	[#2815](https://github.com/weaveworks/scope/pull/2815)
- Time Travel: keep active node details panels up-to-date
	[#2807](https://github.com/weaveworks/scope/pull/2807)
- Time Travel: unmount in the shutdown() action
	[#2801](https://github.com/weaveworks/scope/pull/2801)
- Fixes timetravel timestamp input getting truncatated on OSX
	[#2805](https://github.com/weaveworks/scope/pull/2805)
- Time Travel: remove the feature flag and make the availability depend on historic reports capability
	[#2616](https://github.com/weaveworks/scope/pull/2616)
- log sqs messages at 'debug' rather than 'info' level
	[#2798](https://github.com/weaveworks/scope/pull/2798)
- Fix timeline label vertical displacement on some Chromes
	[#2793](https://github.com/weaveworks/scope/pull/2793)
- Shrink timeline height and make years fade out
	[#2778](https://github.com/weaveworks/scope/pull/2778)
- Always take timestamp into account in Node Details when time travelling
	[#2775](https://github.com/weaveworks/scope/pull/2775)
- Hide Service UI Configure button only in Scope
	[#2766](https://github.com/weaveworks/scope/pull/2766)
- Time Travel 3.0
	[#2703](https://github.com/weaveworks/scope/pull/2703)


## Release 1.6.2

Bugfix patch release

- k8s probe: Fix a panic (nil pointer deref) when a cronjob has never been scheduled
	[#2785](https://github.com/weaveworks/scope/pull/2785)

## Release 1.6.1

This is a re-release of 1.6.0. The official build for 1.6.0 inadvertently
included outdated versions of some components, which introduced security issues.

## Release 1.6.0

Highlights:
- New Kubernetes Controllers view
- Add Kubernetes Stateful Sets and Cron Jobs
- Various small improvements and performance work

New features and enhancements:
- kubernetes: Add StatefulSets and CronJobs
	[#2724](https://github.com/weaveworks/scope/pull/2724)
- Make Resource view nodes clickable
	[#2679](https://github.com/weaveworks/scope/pull/2679)
- Keep topology nav visible if selected
	[#2709](https://github.com/weaveworks/scope/pull/2709)
- Show multiple relatives in the nodes-grid view
	[#2648](https://github.com/weaveworks/scope/pull/2648)
- Remove type filter in controllers view
	[#2670](https://github.com/weaveworks/scope/pull/2670)
- Remove replica sets
	[#2661](https://github.com/weaveworks/scope/pull/2661)
- add k8s combined view
	[#2552](https://github.com/weaveworks/scope/pull/2552)
- Gather Weave Net plugin and proxy info from report
	[#2719](https://github.com/weaveworks/scope/pull/2719)


Performance improvements:
- optimisation: don't copy report stream unnecessarily
	[#2736](https://github.com/weaveworks/scope/pull/2736)
- new full reports are more important than old and shortcut reports
	[#2743](https://github.com/weaveworks/scope/pull/2743)
- increase default conntrack buffer size
	[#2739](https://github.com/weaveworks/scope/pull/2739)
- Use Kubernetes node name to filter pods if possible
	[#2556](https://github.com/weaveworks/scope/pull/2556)
- refactor: remove unnecessary and dead Copy()
	[#2675](https://github.com/weaveworks/scope/pull/2675)
- performance: only color connected once
	[#2635](https://github.com/weaveworks/scope/pull/2635)
- fast network membership check
	[#2625](https://github.com/weaveworks/scope/pull/2625)
- memoize isKnownServices for improved performance
	[#2617](https://github.com/weaveworks/scope/pull/2617)
- faster matching of known services
	[#2613](https://github.com/weaveworks/scope/pull/2613)

Bug fixes and minor improvements:
- k8s: Use 'DaemonSet', 'StatefulSet' etc instead of 'Daemon Set', 'Stateful Set'
	[#2757](https://github.com/weaveworks/scope/pull/2757)
- maximize report publishing timeout
	[#2756](https://github.com/weaveworks/scope/pull/2756)
- do not back off on timeouts when sending reports
	[#2746](https://github.com/weaveworks/scope/pull/2746)
- Fix Pods number in graph not updating (minor label)
	[#2728](https://github.com/weaveworks/scope/pull/2728)
- defend against nils
	[#2734](https://github.com/weaveworks/scope/pull/2734)
- Fix New Version notification not showing
	[#2720](https://github.com/weaveworks/scope/pull/2720)
- render: In minor labels, display '0 things' instead of blank if zero things present
	[#2726](https://github.com/weaveworks/scope/pull/2726)
- Reset nodes in frontend when scope-app restarted
	[#2713](https://github.com/weaveworks/scope/pull/2713)
- Keep topo nav visible if subnav selected
	[#2710](https://github.com/weaveworks/scope/pull/2710)
- don't miss, or fail to forget, initial connections
	[#2704](https://github.com/weaveworks/scope/pull/2704)
- bump tcptracer-bpf version
	[#2705](https://github.com/weaveworks/scope/pull/2705)
- fix ebpf init race segfault
	[#2695](https://github.com/weaveworks/scope/pull/2695)
- Make graph layout zoom limits constant
	[#2678](https://github.com/weaveworks/scope/pull/2678)
- Last line of defense against overlapping nodes in graph layout
	[#2688](https://github.com/weaveworks/scope/pull/2688)
- Fix `yarn pack` ignoring directory cli flag
	[#2694](https://github.com/weaveworks/scope/pull/2694)
- Show table overflow only if limit exceeded by 2+
	[#2683](https://github.com/weaveworks/scope/pull/2683)
- render/pod: Fix a typo in Map2Parent where UnmanagedID will always be used for noParentsPseudoID
	[#2685](https://github.com/weaveworks/scope/pull/2685)
- don't show container count in host detail panel image list
	[#2682](https://github.com/weaveworks/scope/pull/2682)
- correct determination of a host's container images
	[#2680](https://github.com/weaveworks/scope/pull/2680)
- Prevents 6 digit pids from being truncated in details panel/table mode
	[#2666](https://github.com/weaveworks/scope/pull/2666)
- correct polarity of initial connections
	[#2645](https://github.com/weaveworks/scope/pull/2645)
- ensure connections from /proc/net/tcp{,6} get the right pid
	[#2639](https://github.com/weaveworks/scope/pull/2639)
- Avoid race conditions in DNSSnooper's cached domains
	[#2637](https://github.com/weaveworks/scope/pull/2637)
- Fix issues with union types
	[#2633](https://github.com/weaveworks/scope/pull/2633)
- Fix typo in site/plugins.md
	[#2624](https://github.com/weaveworks/scope/pull/2624)
- correct `nodeSummaryGroupSpec`
	[#2631](https://github.com/weaveworks/scope/pull/2631)
- Ignore ipv6
	[#2622](https://github.com/weaveworks/scope/pull/2622)
- Fix the table sorting order bug for numerical values
	[#2587](https://github.com/weaveworks/scope/pull/2587)
- Fix zoom for `npm start`
	[#2605](https://github.com/weaveworks/scope/pull/2605)
- fix error when docker DAEMON is running with user namespace enabled.
	[#2582](https://github.com/weaveworks/scope/pull/2582)
- Do not read tcp6 files if TCP version 6 isn't supported
	[#2604](https://github.com/weaveworks/scope/pull/2604)
- Elide token-only credentials in cli arguments
	[#2593](https://github.com/weaveworks/scope/pull/2593)
- do not filter endpoints by procspied/ebpf in renderers
	[#2652](https://github.com/weaveworks/scope/pull/2652)

Internal improvements and cleanup:
- Pass build tags to unit tests
	[#2618](https://github.com/weaveworks/scope/pull/2618)
- Allows to skip client build when doing make prog/scope
	[#2732](https://github.com/weaveworks/scope/pull/2732)
- only pass WEAVESCOPE_DOCKER_ARGS to actual probe/app start
	[#2715](https://github.com/weaveworks/scope/pull/2715)
- Set package.json version to 0.0.0
	[#2692](https://github.com/weaveworks/scope/pull/2692)
- simplify connection join
	[#2714](https://github.com/weaveworks/scope/pull/2714)
- EbpfTracker refactoring / cleanup
	[#2699](https://github.com/weaveworks/scope/pull/2699)
- Yarn prefixes version with `v` when packing
	[#2691](https://github.com/weaveworks/scope/pull/2691)
- don't use eBPF in a couple of tests
	[#2690](https://github.com/weaveworks/scope/pull/2690)
- Update README/Makefile/package.json to use yarn
	[#2676](https://github.com/weaveworks/scope/pull/2676)
- render/pod: Remove unused options and incorrect code
	[#2673](https://github.com/weaveworks/scope/pull/2673)
- Use new k8s go client
	[#2659](https://github.com/weaveworks/scope/pull/2659)
- Update github.com/weaveworks/common & dependencies (needs go1.8)
	[#2570](https://github.com/weaveworks/scope/pull/2570)
- Publish updated OpenShift instructions (close #2485)
	[#2657](https://github.com/weaveworks/scope/pull/2657)
- make integration tests pass with latest Weave Net release (2.0)
	[#2641](https://github.com/weaveworks/scope/pull/2641)
- Improved rendering order of nodes/edges in Graph View
	[#2623](https://github.com/weaveworks/scope/pull/2623)
- refactor: extract a couple of heavily used constants
	[#2632](https://github.com/weaveworks/scope/pull/2632)
- Use latest go1.8.3
	[#2626](https://github.com/weaveworks/scope/pull/2626)
- Use Go 1.8
	[#2621](https://github.com/weaveworks/scope/pull/2621)
- Use 127.0.0.1 instead of localhost, more
	[#2554](https://github.com/weaveworks/scope/pull/2554)
- Moved highlighted nodes/edges info to selectors
	[#2584](https://github.com/weaveworks/scope/pull/2584)
- rationalise report set usage
	[#2671](https://github.com/weaveworks/scope/pull/2671)
- ignore endpoints with >1 adjacency in process rendering
	[#2668](https://github.com/weaveworks/scope/pull/2668)
- Honor DOCKER_* env variables in probe and app
	[#2649](https://github.com/weaveworks/scope/pull/2649)

Weave Cloud related changes:
- Back off when writing to Dynamo and S3
	[#2723](https://github.com/weaveworks/scope/pull/2723)
- Time travel redesign
	[#2651](https://github.com/weaveworks/scope/pull/2651)
- Make API calls with time travel timestamp
	[#2600](https://github.com/weaveworks/scope/pull/2600)

## Release 1.5.1

Bugfix patch release

Bug fixes:
- initial connections have wrong polarity
	[#2644](https://github.com/weaveworks/scope/issues/2644)
- connection to dead process associated with different process
	[#2638](https://github.com/weaveworks/scope/pull/2638)

## Release 1.5.0

Highlights:
- More accurate and cheaper connection tracking with eBPF, which now is enabled by default.
- Bug fixes and performance improvements.

New features and enhancements:
- Enable eBPF tracking by default
	[#2535](https://github.com/weaveworks/scope/pull/2535)
- Elide url passwords in cli arguments
	[#2568](https://github.com/weaveworks/scope/pull/2568)

Performance improvements:
- drop addr and port from Endpoint.Latest map
	[#2581](https://github.com/weaveworks/scope/pull/2581)
- parallel reduce
	[#2561](https://github.com/weaveworks/scope/pull/2561)
- don't read all of /proc when probe.proc.spy=false
	[#2557](https://github.com/weaveworks/scope/pull/2557)
- optimise: don't sort in NodeSet.ForEach
	[#2548](https://github.com/weaveworks/scope/pull/2548)
- encode empty ps.Maps as nil
	[#2547](https://github.com/weaveworks/scope/pull/2547)

Bug fixes:
- re-target app clients when name resolution changes
	[#2579](https://github.com/weaveworks/scope/pull/2579)
- correct type for "Observed Gen."
	[#2572](https://github.com/weaveworks/scope/pull/2572)
- Back off upon errored kubernetes api requests
	[#2562](https://github.com/weaveworks/scope/pull/2562)
- Close eBPF tracker cleanly
	[#2541](https://github.com/weaveworks/scope/pull/2541)
- Simplify connection tracker init and fix procfs scan fallback
	[#2539](https://github.com/weaveworks/scope/pull/2539)
- Guard against null DaemonSet store
	[#2538](https://github.com/weaveworks/scope/pull/2538)

Internal improvements and cleanup:
- es6ify server.js and include in eslint
	[#2560](https://github.com/weaveworks/scope/pull/2560)
- Fix prog/main_test.go
	[#2567](https://github.com/weaveworks/scope/pull/2567)
- Fix incomplete dependencies for `make scope/prog`
	[#2563](https://github.com/weaveworks/scope/pull/2563)
- bump package.json version to current scope version
	[#2555](https://github.com/weaveworks/scope/pull/2555)
- simplify connection join
	[#2559](https://github.com/weaveworks/scope/pull/2559)
- Use map helpers
	[#2546](https://github.com/weaveworks/scope/pull/2546)
- add copyreport utility
	[#2542](https://github.com/weaveworks/scope/pull/2542)

Weave Cloud related changes:
- Time travel control
	[#2524](https://github.com/weaveworks/scope/pull/2524)
- Add app capabilities to /api endpoint
	[#2575](https://github.com/weaveworks/scope/pull/2575)


## Release 1.4.0

Highlights:
- New Docker Swarm view
- New Kubernetes DaemonSets view 
- Probe performance improvements
- Many bugfixes

New features and enhancements:
- Add Docker Swarm view
	[#2444](https://github.com/weaveworks/scope/pull/2444)
	[#2452](https://github.com/weaveworks/scope/pull/2452)
	[#2450](https://github.com/weaveworks/scope/pull/2450)
- Kuebrnetes: add daemonsets
	[#2526](https://github.com/weaveworks/scope/pull/2526)	
- Canvas zoom control
	[#2513](https://github.com/weaveworks/scope/pull/2513)
- Consistent resource consumption info in the resource view
	[#2499](https://github.com/weaveworks/scope/pull/2499)
- k8s: show all namespaces by default
	[#2522](https://github.com/weaveworks/scope/pull/2522)
- Hide container image status for pseudo nodes
	[#2520](https://github.com/weaveworks/scope/pull/2520)
- Break out some Azure-based services from "The Internet"
	[#2521](https://github.com/weaveworks/scope/pull/2521)
- Remove zoom on double-click
	[#2457](https://github.com/weaveworks/scope/pull/2457)
- allow disabling of weaveDNS advertising/lookup
	[#2445](https://github.com/weaveworks/scope/pull/2445)

Performance improvements:
- process walker perfs: optimize readLimits and readStats
	[#2491](https://github.com/weaveworks/scope/pull/2491)
- proc walker: optimize open file counter
	[#2456](https://github.com/weaveworks/scope/pull/2456)
- eliminate excessive calls to mtime.Now()
	[#2486](https://github.com/weaveworks/scope/pull/2486)
- Msgpack perf: write psMap out directly
	[#2466](https://github.com/weaveworks/scope/pull/2466)
- proc_linux: don't exec `getNetNamespacePathSuffix()` on every walk
	[#2453](https://github.com/weaveworks/scope/pull/2453)
- gzip: change compression level to the default
	[#2437](https://github.com/weaveworks/scope/pull/2437)

Bug fixes:
- Let conntrack track non-NATed short-lived connections
	[#2527](https://github.com/weaveworks/scope/pull/2527)
- Re-enable pod shortcut reports
	[#2528](https://github.com/weaveworks/scope/pull/2528)
- ebpf connection tracker: perf map fixes
	[#2507](https://github.com/weaveworks/scope/pull/2507)
- ebpf: handle fdinstall events from tcptracer-bpf (aka "accept before kretprobe" issue)
	[#2518](https://github.com/weaveworks/scope/pull/2518)	
- Fix arrow heads positioning
	[#2505](https://github.com/weaveworks/scope/pull/2505)
- Avoid null dereferences in ECS client
	[#2514](https://github.com/weaveworks/scope/pull/2514)
	[#2515](https://github.com/weaveworks/scope/pull/2515)
- api_topologies: Don't put namespace filters on containers-by-dns/image
	[#2506](https://github.com/weaveworks/scope/pull/2506)
- Log specific error when deployments are not supported
	[#2501](https://github.com/weaveworks/scope/pull/2501)
- Missing namespace option in url state breaks filters
	[#2490](https://github.com/weaveworks/scope/issues/2490)
- Metric selector not showing pinned metric highlighted
	[#2467](https://github.com/weaveworks/scope/issues/2467)
- Fixed view mode switching keyboard shortcuts
	[#2471](https://github.com/weaveworks/scope/pull/2471)
- don't lie about reachable address
	[#2443](https://github.com/weaveworks/scope/pull/2443)
- Fix node highlight for all shapes
	[#2430](https://github.com/weaveworks/scope/pull/2430)
- View mode selector not responding well to resize
	[#2396](https://github.com/weaveworks/scope/issues/2396)
- Empty metric selector appearing as a dot
	[#2425](https://github.com/weaveworks/scope/issues/2425)
- Cloud node border too thin comparing to other nodes
	[#2417](https://github.com/weaveworks/scope/issues/2417)
- Table-mode: origin of details panel is not where clicked
	[#1754](https://github.com/weaveworks/scope/issues/1754)
- Table-mode: tooltip for "The Internet" is missing minor label
	[#1884](https://github.com/weaveworks/scope/issues/1884)
- Fixes loading of viewState from localStorage into URL
	[#2409](https://github.com/weaveworks/scope/pull/2409)
- Don't reset zoom on refresh layout
	[#2407](https://github.com/weaveworks/scope/pull/2407)
- Hide the opened help panel when clicking on the search bar icon
	[#2406](https://github.com/weaveworks/scope/pull/2406)

Documentation:
- Report data structure documentation
	[#2025](https://github.com/weaveworks/scope/pull/2025)
- Add multicolumn-table documentation
	[#2516](https://github.com/weaveworks/scope/pull/2516)
- Update k8s installation instructions
	[#2512](https://github.com/weaveworks/scope/pull/2512)
	[#2519](https://github.com/weaveworks/scope/pull/2519)
- Update install docs
	[#2257](https://github.com/weaveworks/scope/pull/2257)	
- Add plugin mention to scope readme
	[#2454](https://github.com/weaveworks/scope/pull/2454)
- Fix disabling Scope in the ECS AMI
	[#2435](https://github.com/weaveworks/scope/pull/2435)
- Add AMI docs into main docs, modified weave token instructions in one place
	[#2307](https://github.com/weaveworks/scope/pull/2307)
	[#2416](https://github.com/weaveworks/scope/pull/2416)
	[#2415](https://github.com/weaveworks/scope/pull/2415)

Internal improvements and cleanup:
- Reduce the number of places topologies are explicitly listed
	[#2436](https://github.com/weaveworks/scope/pull/2436)
- Use prop-types library to silence PropTypes deprecation warning
	[#2498](https://github.com/weaveworks/scope/pull/2498)
- Update node libraries
	[#2292](https://github.com/weaveworks/scope/pull/2292)
- Added search type variable
	[#2493](https://github.com/weaveworks/scope/pull/2493)
- Add website preview via Netlify
	[#2480](https://github.com/weaveworks/scope/pull/2480)
- Consisten spacing in Markdown headings
	[#2438](https://github.com/weaveworks/scope/pull/2438)
- only lint files in git ls-files, not .git/*
	[#2477](https://github.com/weaveworks/scope/pull/2477)
- publish master to dockerhub (again)
	[#2449](https://github.com/weaveworks/scope/pull/2449)
- scope script: Allow 'user' part of image name to be given by DOCKERHUB_USER env var
	[#2447](https://github.com/weaveworks/scope/pull/2447)
- Make various anonymous fields named
	[#2419](https://github.com/weaveworks/scope/pull/2419)
- vendor: update gobpf and tcptracer-bpf
	[#2428](https://github.com/weaveworks/scope/pull/2428)
- extras/dialer updates and fixes
	[#2350](https://github.com/weaveworks/scope/pull/2350)
- Update tcptracer-bpf and re-enable test 311
	[#2411](https://github.com/weaveworks/scope/pull/2411)
- Add check for old options
	[#2405](https://github.com/weaveworks/scope/pull/2405)
- shfmt: fix shell formatting
	[#2533](https://github.com/weaveworks/scope/pull/2533)

Weave Cloud related changes:
- close s3 response body to prevent leaks
	[#2442](https://github.com/weaveworks/scope/pull/2442)
- Add service images widget
	[#2487](https://github.com/weaveworks/scope/pull/2487)
- Add weavenet metrics to billing
	[#2504](https://github.com/weaveworks/scope/pull/2504)
- Calculate viewport dimensions from the scope-app div
	[#2473](https://github.com/weaveworks/scope/pull/2473)
- Added mixpanel tracking for some basic events
	[#2462](https://github.com/weaveworks/scope/pull/2462)
- Add NodeSeconds to billing emitter
	[#2422](https://github.com/weaveworks/scope/pull/2422)


## Release 1.3.0

Highlights:
- New resource usage view
- New Arrows in graph view to indicate connection directions
- [Weave Cloud Agent Docker-certified image](https://store.docker.com/images/f18f278a-54c1-4f25-b252-6e11112776c5)
- eBPF connection tracking (enabled with --probe.ebpf.connections=true)

New features and enhancements:
- Resource usage view
	[#2296](https://github.com/weaveworks/scope/pull/2296)
	[#2390](https://github.com/weaveworks/scope/pull/2390)
- Edge arrows
	[#2317](https://github.com/weaveworks/scope/pull/2317)
	[#2342](https://github.com/weaveworks/scope/pull/2342)
- Add eBPF connection tracking
	[#2135](https://github.com/weaveworks/scope/pull/2135)
	[#2327](https://github.com/weaveworks/scope/pull/2327)
	[#2336](https://github.com/weaveworks/scope/pull/2336)
	[#2366](https://github.com/weaveworks/scope/pull/2366)
-	View multiple Kubernetes namespaces at once
 	[#2404](https://github.com/weaveworks/scope/pull/2404)
- Exclude pause containers when rendering k8s topologies
	[#2338](https://github.com/weaveworks/scope/pull/2338)
- When k8s present, allow filtering of containers by namespace
	[#2285](https://github.com/weaveworks/scope/pull/2285)
	[#2348](https://github.com/weaveworks/scope/pull/2348)
	[#2362](https://github.com/weaveworks/scope/pull/2362)
- Add ECS Service scale up/down controls
	[#2197](https://github.com/weaveworks/scope/pull/2197)
- Improve error reporting when invoking weave script
	[#2335](https://github.com/weaveworks/scope/pull/2335)
- Add options to hide args and env vars
	[#2306](https://github.com/weaveworks/scope/pull/2306)
	[#2311](https://github.com/weaveworks/scope/pull/2311)
	[#2310](https://github.com/weaveworks/scope/pull/2310)
- Add loading indicator on topology option change
	[#2272](https://github.com/weaveworks/scope/pull/2272)
- report playback
	[#2301](https://github.com/weaveworks/scope/pull/2301)
- Show loading indicator on topology changes
	[#2232](https://github.com/weaveworks/scope/pull/2232)

Performance improvements:
- Map decode optimisations
	[#2364](https://github.com/weaveworks/scope/pull/2364)
- Remove LatestMap, to reduce memory allocation
	[#2351](https://github.com/weaveworks/scope/pull/2351)
- Decode via byte slice for memcache and file read
	[#2331](https://github.com/weaveworks/scope/pull/2331)
- quantise reports
	[#2305](https://github.com/weaveworks/scope/pull/2305)
- Layout rendering dynamic optimizations
	[#2221](https://github.com/weaveworks/scope/pull/2221)
	[#2265](https://github.com/weaveworks/scope/pull/2265)

Bug fixes:
- Pinned metric temporarily not displayed on mouse leave
	[#2397](https://github.com/weaveworks/scope/issues/2397)
- Search doesn't consider nodes of unloaded topologies
	[#2395](https://github.com/weaveworks/scope/issues/2393)
- Help panel height overflow in Containers view
	[#2352](https://github.com/weaveworks/scope/issues/2352)
- "Save canvas as SVG" button shown in table mode
	[#2354](https://github.com/weaveworks/scope/pull/2354)
- process with no cmd are shown with no name
	[#2315](https://github.com/weaveworks/scope/issues/2315)
- Throb animation is called on graph nodes even when the search query doesn't change
	[#2255](https://github.com/weaveworks/scope/issues/2255)
- pod names missing
	[#2258](https://github.com/weaveworks/scope/issues/2258)
- parse --probe-only as intended
	[#2300](https://github.com/weaveworks/scope/pull/2300)
- Graph view zoom states get reset when switching to table view
	[#2254](https://github.com/weaveworks/scope/issues/2254)
- graph not rendered top-down, despite lack of cycles
	[#2267](https://github.com/weaveworks/scope/issues/2267)
- Hide Uncontained filter in DNS view not hiding uncontained
	[#2170](https://github.com/weaveworks/scope/issues/2170)

Documentation:
- Documentation improvements
	[#2252](https://github.com/weaveworks/scope/pull/2252)
- Removed missed merge text and made terminology consistent
	[#2289](https://github.com/weaveworks/scope/pull/2289)

Internal improvements and cleanup:
- integration test: disable flaky test 311
	[#2380](https://github.com/weaveworks/scope/pull/2380)
- Add job to trigger service-ui build
	[#2376](https://github.com/weaveworks/scope/pull/2376)
- Use yarn package manager
	[#2368](https://github.com/weaveworks/scope/pull/2368)
- integration tests: list containers for debugging
	[#2346](https://github.com/weaveworks/scope/pull/2346)
- scope: use same Docker args for early dry run
	[#2326](https://github.com/weaveworks/scope/pull/2326)
	[#2358](https://github.com/weaveworks/scope/pull/2358)
- Bump react version
	[#2339](https://github.com/weaveworks/scope/pull/2339)
- integration: disable tests with internet edge
	[#2314](https://github.com/weaveworks/scope/pull/2314)
- Secure integration tests
	[#2312](https://github.com/weaveworks/scope/pull/2312)
- integration: restart docker daemon after each test
	[#2298](https://github.com/weaveworks/scope/pull/2298)
- Changed ui-build-pkg job to use a docker container
	[#2281](https://github.com/weaveworks/scope/pull/2281)
- integration tests: fix scripts
	[#2225](https://github.com/weaveworks/scope/pull/2225)
- circle.yml: Fix ui upload step so it doesn't build twice
	[#2266](https://github.com/weaveworks/scope/pull/2266)

Weave Cloud related changes:
- Create cloud agent image
	[#2284](https://github.com/weaveworks/scope/pull/2284)
	[#2277](https://github.com/weaveworks/scope/pull/2277)
	[#2278](https://github.com/weaveworks/scope/pull/2278)
- Container Seconds should not be Container Nanoseconds
	[#2372](https://github.com/weaveworks/scope/pull/2372)
- Clear client polling and nodes state on dismount
	[#2361](https://github.com/weaveworks/scope/pull/2361)
- Fluent Billing Emitter
	[#2359](https://github.com/weaveworks/scope/pull/2359)
- Correct dynamoDB metric label
	[#2344](https://github.com/weaveworks/scope/pull/2344)
- Add logic to turn off network requests when Scope dismounts
	[#2290](https://github.com/weaveworks/scope/pull/2290)
	[#2340](https://github.com/weaveworks/scope/pull/2340)
- Load contrast stylesheet
	[#2256](https://github.com/weaveworks/scope/pull/2256)
- Consolidate API requests into single helper; added CSRF header
	[#2260](https://github.com/weaveworks/scope/pull/2260)
- Add logic to remove non-transferrable state when switching Cloud instances
	[#2237](https://github.com/weaveworks/scope/pull/2237)


## Release 1.2.1
This is a minor patch release.

Documentation
- Uploaded new cloud token screenshot
	[#2248](https://github.com/weaveworks/scope/pull/2248)
- Updated cloud description
	[#2249](https://github.com/weaveworks/scope/pull/2249)

Bugfixes
- Fix help menu not opening from 'search' hint
	[#2230](https://github.com/weaveworks/scope/pull/2230)
- Re-factor API URL generation code
	[#2202](https://github.com/weaveworks/scope/pull/2202)

Improvements
- Reintroduce probe checkpoint flags for kernel version and OS
	[#2224](https://github.com/weaveworks/scope/pull/2224)
- Upgraded xterm.js to 2.2.3
	[#2126](https://github.com/weaveworks/scope/pull/2126)
- Allow random seed in dialer
	[#2206](https://github.com/weaveworks/scope/pull/2206)
- Rename ECS Service node ids to be cluster;serviceName
	[#2186](https://github.com/weaveworks/scope/pull/2186)

## Release 1.2.0

Highlights:
- Performance improvements (both in UI and probes).
- Scope now requires Docker version >= 1.10.

New features and enhancements:
- ECS: service details panel should list its tasks
	[#2041](https://github.com/weaveworks/scope/issues/2041)
- Prioritize ecs topologies on initial load if available
	[#2105](https://github.com/weaveworks/scope/pull/2105)
- Add control status icon to Terminal header
	[#2087](https://github.com/weaveworks/scope/pull/2087)
- scope launch script improvements
	[#2077](https://github.com/weaveworks/scope/pull/2077)
	[#2093](https://github.com/weaveworks/scope/pull/2093)
- Maintain focus on hovered node table rows
	[#2115](https://github.com/weaveworks/scope/pull/2115)
- Add control to reset local view state
	[#2080](https://github.com/weaveworks/scope/pull/2080)
- Check that conntrack events are enabled in the kernel
	[#2112](https://github.com/weaveworks/scope/pull/2112)
- Hardcode 127.0.0.1 as loopback IP for default target
	[#2103](https://github.com/weaveworks/scope/pull/2103)
- prog/main: use flags.app.port for default target
	[#2096](https://github.com/weaveworks/scope/pull/2096)

Performance improvements:
- Graph layout optimizations
	[#2128](https://github.com/weaveworks/scope/pull/2128)
	[#2179](https://github.com/weaveworks/scope/pull/2179)
	[#2180](https://github.com/weaveworks/scope/pull/2180)
	[#2210](https://github.com/weaveworks/scope/pull/2210)
- Disable XML in conntrack parsing
	[#2095](https://github.com/weaveworks/scope/pull/2095)
	[#2118](https://github.com/weaveworks/scope/pull/2118)

Bug fixes:
- ECS reporter throttled by AWS API
	[#2050](https://github.com/weaveworks/scope/issues/2050)
- Already closed connections showing up in the containers tab
	[#2181](https://github.com/weaveworks/scope/issues/2181)
- Node details spinner Chrome display bug fix
	[#2177](https://github.com/weaveworks/scope/pull/2177)
- fix error when docker daemon is running with user namespace enabled.
	[#2161](https://github.com/weaveworks/scope/pull/2161)
	[#2176](https://github.com/weaveworks/scope/pull/2176)
- DNSSnooper: Support Dot1Q and limit decoding errors
	[#2155](https://github.com/weaveworks/scope/issues/2155)
- Contrast mode not working
	[#2165](https://github.com/weaveworks/scope/issues/2165)
	[#2138](https://github.com/weaveworks/scope/issues/2138)
- Scope does not create special nodes within the same VPC
	[#2163](https://github.com/weaveworks/scope/issues/2163)
- default view fails to select 'application containers only'
	[#2120](https://github.com/weaveworks/scope/issues/2120)
- ECS: Missing link to task on container details panel
	[#2040](https://github.com/weaveworks/scope/issues/2040)
- kubernetes reporter is broken on katacoda
	[#2049](https://github.com/weaveworks/scope/pull/2049)
- probe's procspy does not report netcat's half-duplex long-lived connections
	[#1972](https://github.com/weaveworks/scope/issues/1972)
- Sparkline component throws errors when a container is turned off
	[#2072](https://github.com/weaveworks/scope/pull/2072)
- Graph/table buttons don't resize nicely
	[#2056](https://github.com/weaveworks/scope/issues/2056)
- JS error on edges with lots of waypoints
	[#1187](https://github.com/weaveworks/scope/issues/1187)
- Fix two bugs caused by transition to D3 v4
	[#2048](https://github.com/weaveworks/scope/pull/2048)
- Popped out terminal styles don't quite align with in-scope terminal styles
	[#2209](https://github.com/weaveworks/scope/issues/2209)
- Radii of rounded-corner shape don't quite align
	[#2212](https://github.com/weaveworks/scope/issues/2212)

Documentation:
- Fix Scope arguments in Docker Compose installation docs
	[#2143](https://github.com/weaveworks/scope/pull/2143)
- Document how to run tests on website
	[#2131](https://github.com/weaveworks/scope/pull/2131)
- Follow redirections in curl when getting k8s resources
	[#2067](https://github.com/weaveworks/scope/pull/2067)

Internal improvements and cleanup:
- Embed and require Docker >= 1.10
	[#2190](https://github.com/weaveworks/scope/pull/2190)
- don't attempt to make 'make clean' work on old checkouts
	[#2189](https://github.com/weaveworks/scope/pull/2189)
- Fix linter errors
	[#2068](https://github.com/weaveworks/scope/pull/2068)
	[#2166](https://github.com/weaveworks/scope/pull/2166)
- Fix ownership issues with client/build-external
	[#2153](https://github.com/weaveworks/scope/pull/2153)
- Allow Scope UI to be installed as a Node module
	[#2144](https://github.com/weaveworks/scope/pull/2144)
	[#2159](https://github.com/weaveworks/scope/pull/2159)
- Upgrade container base image to alpine:3.5
	[#2158](https://github.com/weaveworks/scope/pull/2158)
- Use Sass instead of Less
	[#2141](https://github.com/weaveworks/scope/pull/2141)
- probe: refactor probeMain
	[#2148](https://github.com/weaveworks/scope/pull/2148)
- Update to go1.7.4
	[#2147](https://github.com/weaveworks/scope/pull/2147)
- Bump tools subtree and fix integration tests
	[#2136](https://github.com/weaveworks/scope/pull/2136)
- Add support for generic multicolumn tables
	[#2109](https://github.com/weaveworks/scope/pull/2109)
- extras/dialer: move dialer.go to sub directory
	[#2108](https://github.com/weaveworks/scope/pull/2108)
- Forward OS/Kernel version to checkpoint
	[#2101](https://github.com/weaveworks/scope/pull/2101)
- Fix force-push to master
	[#2094](https://github.com/weaveworks/scope/pull/2094)
- Upgraded eslint & eslint-config-airbnb
	[#2058](https://github.com/weaveworks/scope/pull/2058)
	[#2084](https://github.com/weaveworks/scope/pull/2084)
	[#2089](https://github.com/weaveworks/scope/pull/2089)
- ecs reporter: Fix some log lines that were passing *string instead of string
	[#2060](https://github.com/weaveworks/scope/pull/2060)
- Add flag for logging headers
	[#2086](https://github.com/weaveworks/scope/pull/2086)
- Add extras/dialer
	[#2082](https://github.com/weaveworks/scope/pull/2082)
- Remove wcloud
	[#2081](https://github.com/weaveworks/scope/pull/2081)
- Add client linting to CI config
	[#2076](https://github.com/weaveworks/scope/pull/2076)
- Importing lodash util functions explicitly
	[#2053](https://github.com/weaveworks/scope/pull/2053)
- procspy: use a Reader to copy the background reader buffer
	[#2020](https://github.com/weaveworks/scope/pull/2020)
- Use newly-created 'common' repo
	[#2061](https://github.com/weaveworks/scope/pull/2061)
- Fix all the npm library versions
	[#2057](https://github.com/weaveworks/scope/pull/2057)
- linter: fix punctuation and capitalization
	[#2021](https://github.com/weaveworks/scope/pull/2021)
- Using `webpack-dev-middleware` instead of `webpack-dev-server` directly
	[#2034](https://github.com/weaveworks/scope/pull/2034)
- Create `latest_release` Docker image tag during release process
	[#2216](https://github.com/weaveworks/scope/issues/2216)

Weave Cloud related changes:
- Deploy to quay when merging to master
	[#2134](https://github.com/weaveworks/scope/pull/2134)
- Removed leading slash from getAllNodes() api request
	[#2124](https://github.com/weaveworks/scope/pull/2124)
- Correctly instrument websocket handshakes
	[#2074](https://github.com/weaveworks/scope/pull/2074)


## Release 1.1.0

Highlights:
- New ECS view which allows visualizing your tasks and services in Amazon's EC2 Container Service.
- Custom label-based container filters can be defined through `--app.container-label-filter`

New features and enhancements:
- Add ECS views
	[#2026](https://github.com/weaveworks/scope/pull/2026)
- Add custom label-based filters in container view
	[#1895](https://github.com/weaveworks/scope/pull/1895)
- Improve plugin errors tooltip
	[#2022](https://github.com/weaveworks/scope/pull/2022)
- Add anti-dance heuristics (and feature flags)
	[#1993](https://github.com/weaveworks/scope/pull/1993)
- Table-mode: sort ips numerically
	[#2007](https://github.com/weaveworks/scope/pull/2007)
- increase black/white text contrast in contrast mode
	[#2006](https://github.com/weaveworks/scope/pull/2006)
- Improve view-node-in-topo button usability
	[#1926](https://github.com/weaveworks/scope/pull/1926)
- Hide Weave topology if empty
	[#2035](https://github.com/weaveworks/scope/pull/2035)

Performance improvements:
- Add graph complexity check on page load
	[#1994](https://github.com/weaveworks/scope/pull/1994)

Bug fixes:
- plug goroutine leak in control
	[#2003](https://github.com/weaveworks/scope/pull/2003)
- Fix details panel not closing on canvas click
	[#1998](https://github.com/weaveworks/scope/pull/1998)
- Empty publicpath needed for relative paths of scope
	[#2043](https://github.com/weaveworks/scope/pull/2043)

Documentation:
- Use intuitive standalone service name in compose
	[#2019](https://github.com/weaveworks/scope/pull/2019)
- Fix kubectl port-forward command to access the scope app locally
	[#2010](https://github.com/weaveworks/scope/pull/2010)
- Update website plugins documentation
	[#2008](https://github.com/weaveworks/scope/pull/2008)

Internal improvements and cleanup:
- Combined external and prod webpack config files
	[#2014](https://github.com/weaveworks/scope/pull/2014)
- Update package.json
	[#2017](https://github.com/weaveworks/scope/pull/2017)
- Move plugins to the new organization
	[#1906](https://github.com/weaveworks/scope/pull/1906)
- Change webpack local config to use source maps
	[#2011](https://github.com/weaveworks/scope/pull/2011)
- middleware/errorhandler: Implement Hijacker so it works with ws proxy
	[#1971](https://github.com/weaveworks/scope/pull/1971)
- Fix time-dependant test (stop testing docker client library)
	[#2005](https://github.com/weaveworks/scope/pull/2005)
- Give time to the overlay test backoff collectors to finish
	[#1995](https://github.com/weaveworks/scope/pull/1995)
- Update D3 to version 4.4.0
	[#2028](https://github.com/weaveworks/scope/pull/2028)

Weave Cloud related changes:
- Add OpenTracing support to TimeRequestHistogram
	[#2023](https://github.com/weaveworks/scope/pull/2023)

## Release 1.0.0

Highlights:
- New Weave Net View which allows visualizing and troubleshooting your Weave Network.
- New nodes for well-known services. The Internet node is now broken down in individual nodes for known cloud services.
- Improved terminals, with proper resizing, scroll locking and better visuals.
- Refined UI with particularly improved connection information.
- Lots of squashed bugs.

New features and enhancements:
- New Weave Net view
	[#1182](https://github.com/weaveworks/scope/pull/1182)
	[#1973](https://github.com/weaveworks/scope/pull/1973)
	[#1981](https://github.com/weaveworks/scope/pull/1981)
- Show well-known services
	[#1863](https://github.com/weaveworks/scope/pull/1863)
	[#1881](https://github.com/weaveworks/scope/pull/1881)
	[#1887](https://github.com/weaveworks/scope/pull/1887)
	[#1897](https://github.com/weaveworks/scope/pull/1897)
- Terminal improvements
  - Resize TTYs
		[#1966](https://github.com/weaveworks/scope/pull/1966)
		[#1979](https://github.com/weaveworks/scope/pull/1979)
		[#1976](https://github.com/weaveworks/scope/pull/1976)
  - Enable scroll locking on the terminal
		[#1932](https://github.com/weaveworks/scope/pull/1932)
  - Adds tooltip to terminal-popout button
		[#1790](https://github.com/weaveworks/scope/pull/1790)
  - Clarify terminal is child window of details panel.
		[#1903](https://github.com/weaveworks/scope/pull/1903)
  - Use login shells in terminals
		[#1821](https://github.com/weaveworks/scope/pull/1821)
- Miscellaneous UI improvements
  - show more details of a node's internet connections
		[#1875](https://github.com/weaveworks/scope/pull/1875)
  - Close help dialog when the canvas is clicked
		[#1960](https://github.com/weaveworks/scope/pull/1960)
  - Improve metadata table 'date' format
		[#1927](https://github.com/weaveworks/scope/pull/1927)
  - Add a new search section to the help popover
		[#1919](https://github.com/weaveworks/scope/pull/1919)
  - Add label_minor to tooltips in connections table
		[#1912](https://github.com/weaveworks/scope/pull/1912)
  - Add localstorage support for saving view state
		[#1853](https://github.com/weaveworks/scope/pull/1853)
  - Makes services the initial topology if available
		[#1823](https://github.com/weaveworks/scope/pull/1823)
  - Add image information table to container details panel
		[#1942](https://github.com/weaveworks/scope/pull/1942)
- Allow user to specify URLs on the command line, and use that to allow per-target tokens.
	[#1901](https://github.com/weaveworks/scope/pull/1901)
- Apply filters from current view to details panel
	[#1904](https://github.com/weaveworks/scope/pull/1904)
- Increase timestamp precision
	[#1933](https://github.com/weaveworks/scope/pull/1933)
- Add prometheus metrics endpoint to probes.
	[#1915](https://github.com/weaveworks/scope/pull/1915)
- Allow users to specify conntrack buffer size.
	[#1896](https://github.com/weaveworks/scope/pull/1896)
- Plugins: Add support for table based controls
	[#1818](https://github.com/weaveworks/scope/pull/1818)

Performance improvements:
- make smartMerger.Merge merge reports in parallel
	[#1827](https://github.com/weaveworks/scope/pull/1827)

Bug fixes:
- Goroutine leak in scope app
	[#1916](https://github.com/weaveworks/scope/issues/1916)
	[#1920](https://github.com/weaveworks/scope/pull/1920)
- CPU Usage is not accurate on hosts
	[#1664](https://github.com/weaveworks/scope/issues/664)
- Certain query strings would contain a && instead of &
	[#1953](https://github.com/weaveworks/scope/pull/1953)
- Metrics on canvas get stuck
	[#1829](https://github.com/weaveworks/scope/issues/1829)
- conntrack not used even though it's working
	[#1826](https://github.com/weaveworks/scope/issues/1826)
- pod counts and details panel lists do not respect namespace
	[#1824](https://github.com/weaveworks/scope/issues/1824)
- Discard short-lived connections to/from Pods in the host net
	[#1944](https://github.com/weaveworks/scope/pull/1944)
- probe: Stats gathering can be started twice
	[#1799](https://github.com/weaveworks/scope/issues/1799)
- Visual bug where empty span shows up
	[#1945](https://github.com/weaveworks/scope/issues/1945)
- inbound internet connection counts are too fine-grained
	[#1867](https://github.com/weaveworks/scope/issues/1867)
- IP address truncated in Internet node details panel connection list
	[#1862](https://github.com/weaveworks/scope/issues/1862)
- Incorrect number of connections shown on internet nodes
	[#1495](https://github.com/weaveworks/scope/issues/1495)
- details panel connection counts are too high
	[#1842](https://github.com/weaveworks/scope/issues/1842)
- inbound internet connections reverse-resolved incorrectly
	[#1847](https://github.com/weaveworks/scope/issues/1847)
- Scope hangs after browser reload if current topology goes away
	[#1880](https://github.com/weaveworks/scope/issues/1880)
- node names in connection list truncated unnecessarily
	[#1882](https://github.com/weaveworks/scope/issues/1882)
- numeric values in details panel tables should be right aligned
	[#1794](https://github.com/weaveworks/scope/issues/1794)
- Plugin status line is broken
	[#1825](https://github.com/weaveworks/scope/issues/1825)
- Table-mode: non-metric columns are sorted alphabetically reverse
	[#1802](https://github.com/weaveworks/scope/issues/1802)
- Fix argument escaping in Scope
	[#1950](https://github.com/weaveworks/scope/pull/1950)
- Image details panel shows truncated image name instead of ID
	[#1835](https://github.com/weaveworks/scope/issues/1835)
- Truncated tooltips
	[#1139](https://github.com/weaveworks/scope/issues/1139)
- Incorrect height of terminal window in Safari
	[#1986](https://github.com/weaveworks/scope/issues/1986)

Documentation:
- Simplify k8s instructions
	[#1886](https://github.com/weaveworks/scope/pull/1886)
- Improve installation documentation
	[#1838](https://github.com/weaveworks/scope/pull/1838)
- Update Scope version in documentation
	[#1859](https://github.com/weaveworks/scope/pull/1859)

Internal improvements and cleanup:
- Gracefully shutdown app, letting active http requests finish with timeout
	[#1839](https://github.com/weaveworks/scope/pull/1839)
- middleware/errorhandler: Fix a bug which meant it never works
	[#1958](https://github.com/weaveworks/scope/pull/1958)
- middleware: Add an ErrorHandler middleware used to serve an alternate handler on a certain error code
	[#1954](https://github.com/weaveworks/scope/pull/1954)
- Update client deps to use Node v6.9.0
	[#1959](https://github.com/weaveworks/scope/pull/1959)
- Change term.js library to xterm.js
	[#1948](https://github.com/weaveworks/scope/pull/1948)
- Fix linter errors on unkeyed fields
	[#1922](https://github.com/weaveworks/scope/pull/1922)
- Fix linter error for string in context.WithValue
	[#1921](https://github.com/weaveworks/scope/pull/1921)
- Update tools subtree
	[#1937](https://github.com/weaveworks/scope/pull/1937)
- Fix circle.yml to actually deploy external ui changes
	[#1910](https://github.com/weaveworks/scope/pull/1910)
- Extend logging middleware to optionally only log failed HTTP requests
	[#1909](https://github.com/weaveworks/scope/pull/1909)
- Add option to scope to have static content served from S3 instead
	[#1908](https://github.com/weaveworks/scope/pull/1908)
- Upgrade to go1.7
	[#1797](https://github.com/weaveworks/scope/pull/1797)
- circleci: push traffic control plugin image to docker hub
	[#1858](https://github.com/weaveworks/scope/pull/1858)
- refactor: extract pluralization
	[#1855](https://github.com/weaveworks/scope/pull/1855)
- use go-dockerclient's Client.Stats
	[#1833](https://github.com/weaveworks/scope/pull/1833)
- Print logs to debug shutdown integration test
	[#1888](https://github.com/weaveworks/scope/pull/1888)
- Allow a nil RouteMatcher in instrumentation
	[#1852](https://github.com/weaveworks/scope/pull/1852)

Weave Cloud related changes:
- Don't reencode reports in the collector
	[#1819](https://github.com/weaveworks/scope/pull/1819)

## Release 0.17.1

This is a minor patch release.

New features and enhancements:
- Extend kubernetes client flags to match kubectl
	[#1813](https://github.com/weaveworks/scope/pull/1813)

Bug fixes:
- Fix node label overlap
	[#1812](https://github.com/weaveworks/scope/pull/1812)
- Fix `scope stop` on Docker for Mac
	[#1811](https://github.com/weaveworks/scope/pull/1811)


## Release 0.17.0

Highlights:
- New Table Mode as an alternative to Scope's classic graph view. It provides
  higher information density, proving particularly useful when there are many
  nodes in the graph view.
- Considerable performance enhancements: the CPU efficiency of the Scope App has
  increased in more than 50% and the Scope probes over 25%.


New features and enhancements:
- Table mode
	[#1673](https://github.com/weaveworks/scope/pull/1673)
	[#1747](https://github.com/weaveworks/scope/pull/1747)
	[#1753](https://github.com/weaveworks/scope/pull/1753)
	[#1774](https://github.com/weaveworks/scope/pull/1774)
	[#1775](https://github.com/weaveworks/scope/pull/1775)
	[#1784](https://github.com/weaveworks/scope/pull/1784)
- Loading indicator
	[#1485](https://github.com/weaveworks/scope/pull/1485)
- Don't show weavescope logo when running in a frame
	[#1734](https://github.com/weaveworks/scope/pull/1734)
- Reduce horizontal gap between nodes in topology views
	[#1693](https://github.com/weaveworks/scope/pull/1693)
- Elide service-token when logging commandline arguments
	[#1782](https://github.com/weaveworks/scope/pull/1782)
- Don't complain when stopping Scope if it wasn't running
	[#1783](https://github.com/weaveworks/scope/pull/1783)
- Silence abnormal websocket close
	[#1768](https://github.com/weaveworks/scope/pull/1768)
- Eliminate stats log noise from stopped containers
	[#1687](https://github.com/weaveworks/scope/pull/1687)
	[#1798](https://github.com/weaveworks/scope/pull/1798)
- Hide uncontained/unmanaged by default
	[#1694](https://github.com/weaveworks/scope/pull/1694)

Performance improvements:
- Remove and optimize more Copy()s
	[#1739](https://github.com/weaveworks/scope/pull/1739)
- Use slices instead of linked lists for Metric
	[#1732](https://github.com/weaveworks/scope/pull/1732)
- Don't Copy() self on Merge()
	[#1728](https://github.com/weaveworks/scope/pull/1728)
- Improve performance of immutable maps
	[#1720](https://github.com/weaveworks/scope/pull/1720)
- Custom encoder for latest maps
	[#1709](https://github.com/weaveworks/scope/pull/1709)

Bug fixes:
- Connections inside a container shown as going between containers
	[#1733](https://github.com/weaveworks/scope/issues/1733)
- Probes leak two goroutines when closing attach/exec window
	[#1767](https://github.com/weaveworks/scope/issues/1767)
- Scale node labels with the node's size.
	[#1773](https://github.com/weaveworks/scope/pull/1773)
- Kubernetes infra containers seem to resurface in latest on 1.3
	[#1750](https://github.com/weaveworks/scope/issues/1750)
- Search icon is above text
	[#1715](https://github.com/weaveworks/scope/issues/1715)
- Highlighting is unpredictable
	[#1756](https://github.com/weaveworks/scope/pull/1520)
- Details panel truncates port to four digits
	[#1711](https://github.com/weaveworks/scope/issues/1711)
- Stopped containers not shown with their names
	[#1691](https://github.com/weaveworks/scope/issues/1691)
- Terminals don't support quote characters from intl keyboard layouts
	[#1403](https://github.com/weaveworks/scope/issues/1403)

Internal improvements and cleanup:
- Launcher script: Fix inconsistent whitespace
	[#1776](https://github.com/weaveworks/scope/pull/1776)
- Lint fixes
	[#1751](https://github.com/weaveworks/scope/pull/1751)
- Add browser console logging for websocket to render times
	[#1742](https://github.com/weaveworks/scope/pull/1742)
- circle.yml: deploy master with non-upstream hub accounts
	[#1655](https://github.com/weaveworks/scope/pull/1655)
	[#1710](https://github.com/weaveworks/scope/pull/1710)
- Delete unused instrumentation code
	[#1722](https://github.com/weaveworks/scope/pull/1722)
- Update version of build tools
	[#1685](https://github.com/weaveworks/scope/pull/1685)
- Add flag for block profiling
	[#1681](https://github.com/weaveworks/scope/pull/1681)

Weave Cloud related changes:
- Also serve UI under /ui
	[#1752](https://github.com/weaveworks/scope/pull/1752)
- Name our routes, so /metrics gives more sensible aggregations
	[#1723](https://github.com/weaveworks/scope/pull/1723)
- Add options for storing memcached reports with different compression levels
	[#1684](https://github.com/weaveworks/scope/pull/1684)

## Release 0.16.2

Bug fixes:
- Scope fails to launch on fresh Docker for Mac installs
	[#1755](https://github.com/weaveworks/scope/issues/1755)

## Release 0.16.1

This is a bugfix release. In addition, the security of the Scope probe can be hardened by disabling
controls with the new `--probe.no-controls` flag, which prevents users from
opening terminals, starting/stopping containers, viewing logs, etc.

New features and enhancements:
- Allow disabling controls in probes
	[#1627](https://github.com/weaveworks/scope/pull/1627)
- Make it easier to disable weave integrations
	[#1610](https://github.com/weaveworks/scope/pull/1610)
- Print DNS errors
	[#1607](https://github.com/weaveworks/scope/pull/1607)
- Add dry run flag to scope, so when launched we can check the args are valid.
	[#1609](https://github.com/weaveworks/scope/pull/1609)

Performance improvements:
- Use a slice instead of a persistent list for temporary accumulation of lists
	[#1660](https://github.com/weaveworks/scope/pull/1660)

Bug fixes:
- Should check if probe is already running when launch in standalone mode on Docker for Mac
	[#1679](https://github.com/weaveworks/scope/issues/1679)
- Fixes network bars position when a node is selected.
	[#1667](https://github.com/weaveworks/scope/pull/1667)
- Scope fails to launch on latest Docker for Mac (beta18)
	[#1650](https://github.com/weaveworks/scope/pull/1650)
	[#1669](https://github.com/weaveworks/scope/pull/1669)
- Fixes terminal wrapping by syncing docker/term.js terminal widths.
	[#1648](https://github.com/weaveworks/scope/pull/1648)
- Wrongly attributed local side in outbound internet connections
	[#1598](https://github.com/weaveworks/scope/issues/1598)
- Cannot port-forward app from kubernetes with command in documentation
	[#1526](https://github.com/weaveworks/scope/issues/1526)
- Force some known column widths to prevent truncation of others
	[#1641](https://github.com/weaveworks/scope/pull/1641)

Documentation:
- Replace wget in instructions with curl, as it's more widely avail. on macs
	[#1670](https://github.com/weaveworks/scope/pull/1670)
- Don't prepend `scope launch` with sudo
	[#1606](https://github.com/weaveworks/scope/pull/1606)
- Clarify instructions for using Scope with Weave Cloud
	[#1611](https://github.com/weaveworks/scope/pull/1611)
- Re-added signup page
	[#1604](https://github.com/weaveworks/scope/pull/1604)
- weave cloud screen captures
	[#1603](https://github.com/weaveworks/scope/pull/1603)

Internal improvements and cleanup:
- Lint shellscripts from tools
	[#1658](https://github.com/weaveworks/scope/pull/1658)
- Promote fixprobe and delete rest of experimental
	[#1646](https://github.com/weaveworks/scope/pull/1646)
- refactor some timing helpers into a common lib
	[#1642](https://github.com/weaveworks/scope/pull/1642)
- Helper for reading & writing from binary
	[#1600](https://github.com/weaveworks/scope/pull/1600)
- Updates to vendoring document
	[#1595](https://github.com/weaveworks/scope/pull/1595)

Weave Cloud related changes:
- Store a histogram of report sizes
	[#1668](https://github.com/weaveworks/scope/pull/1668)
- Wire up continuous delivery
	[#1654](https://github.com/weaveworks/scope/pull/1654)
- Count memcache requests even if they time out
	[#1662](https://github.com/weaveworks/scope/pull/1662)
- Adding a static report file mode.
	[#1659](https://github.com/weaveworks/scope/pull/1659)
- Bump memcache expiration
	[#1640](https://github.com/weaveworks/scope/pull/1640)
- Fixes to memcache support
	[#1628](https://github.com/weaveworks/scope/pull/1628)
- Refactor caching layers in dynamo collector
	[#1616](https://github.com/weaveworks/scope/pull/1616)
- Rework Scope metrics according to Prometheus conventions.
	[#1615](https://github.com/weaveworks/scope/pull/1615)
- Fix nil pointer error when memcache not enabled
	[#1612](https://github.com/weaveworks/scope/pull/1612)
- Add backoff to the consul client
	[#1608](https://github.com/weaveworks/scope/pull/1608)
- Query memcached from dynamo db collector
	[#1602](https://github.com/weaveworks/scope/pull/1602)
- Use histograms over summaries
	[#1665](https://github.com/weaveworks/scope/pull/1665)


## Release 0.16.0

Highlights:

* New network filter to quickly ascertain what networks your containers belong to.

New features and enhancements:
- Network view
	[#1528](https://github.com/weaveworks/scope/pull/1528)
	[#1593](https://github.com/weaveworks/scope/pull/1593)
- Label deployment nodes with replica count
	[#1530](https://github.com/weaveworks/scope/pull/1530)
- Add flag to disable reporting of processes (and procspied endpoints)
	[#1511](https://github.com/weaveworks/scope/pull/1511)
- Add pod status to summary table
	[#1523](https://github.com/weaveworks/scope/pull/1523)
- Add filters for pseudo nodes.
	[#1581](https://github.com/weaveworks/scope/pull/1581)

Performance improvements:
- Fast start the dns resolution ticker to improve first report latency.
	[#1508](https://github.com/weaveworks/scope/pull/1508)

Bug fixes:
- Fix tall search box in Firefox
	[#1583](https://github.com/weaveworks/scope/pull/1583)
- Probe reporter stuck
	[#1576](https://github.com/weaveworks/scope/issues/1576)
- Container in multiple networks not showing all connections
	[#1573](https://github.com/weaveworks/scope/issues/1573)
- scope probe connects to localhost & prod even when given explicit hostnames
	[#1566](https://github.com/weaveworks/scope/issues/1566)
- Fix Docker for Mac check
	[#1551](https://github.com/weaveworks/scope/pull/1551)
- If k8s objects only have one container, show that container's metrics on them
	[#1473](https://github.com/weaveworks/scope/pull/1473)
- Don't ever store NEW conntrack flows (only ever store updates).
	[#1541](https://github.com/weaveworks/scope/pull/1541)
- Pods with > 1 container making connections do not show any connections
	[#1494](https://github.com/weaveworks/scope/issues/1494)
- Missing edges when using Docker's IPAM driver
	[#1563](https://github.com/weaveworks/scope/issues/1563)
- Duplicate stack in "by image" view
	[#1521](https://github.com/weaveworks/scope/issues/1521)

Documentation:
- Clarify kubectl version matching
	[#1582](https://github.com/weaveworks/scope/pull/1582)
- updated Weave Cloud and clarified setup
	[#1586](https://github.com/weaveworks/scope/pull/1586)

Internal improvements and cleanup:
- Add Identity middleware
	[#1574](https://github.com/weaveworks/scope/pull/1574)
- Rewrite net/http.Request.{URL.Path,RequestURI} consistently
	[#1555](https://github.com/weaveworks/scope/pull/1555)
- Add Marathon JSON for launching on minimesos cluster
	[#1509](https://github.com/weaveworks/scope/pull/1509)
- Circle integration for auto docs publishing.
	[#1517](https://github.com/weaveworks/scope/pull/1517)
- Tag scope images on docker hub as we do in service
	[#1572](https://github.com/weaveworks/scope/pull/1572)
- Scope slow: improve error messages for debugging
	[#1534](https://github.com/weaveworks/scope/pull/1534)
- circle.yml: deploy non-master branches
	[#1535](https://github.com/weaveworks/scope/pull/1535)
- Add docker hub badge
	[#1540](https://github.com/weaveworks/scope/pull/1540)
- Increase test replicas
	[#1529](https://github.com/weaveworks/scope/pull/1529)
- Ignore IPv6 addresses in Docker reporter
	[#1552](https://github.com/weaveworks/scope/pull/1552)

Weave Cloud related changes:
- Add probe version header to probe requests
	[#1564](https://github.com/weaveworks/scope/pull/1564)
- Fetch non-cached reports in parallel
	[#1554](https://github.com/weaveworks/scope/pull/1554)
- Various fix ups for multitenancy
	[#1533](https://github.com/weaveworks/scope/pull/1533)
- Use NATS for shortcut reports in the service.
	[#1568](https://github.com/weaveworks/scope/pull/1568)
- If we don't get a path name from the router, make one up from the url.
	[#1570](https://github.com/weaveworks/scope/pull/1570)
- Log errors in response to http requests.
	[#1569](https://github.com/weaveworks/scope/pull/1569)
- Put reports in S3; add in process caching
	[#1545](https://github.com/weaveworks/scope/pull/1545)
- Use smart merger in the DynamoDB collector.
	[#1543](https://github.com/weaveworks/scope/pull/1543)
- Allow user to specify table name and queue prefix.
	[#1538](https://github.com/weaveworks/scope/pull/1538)
- Get route name before munging request
	[#1590](https://github.com/weaveworks/scope/pull/1590)


## Release 0.15.0

Highlights:

This release comes with:
  * Search: new smart search field that allows you to filter what you can see by
    container names, all kinds of metadata, e.g., IP addresses, and metric
    comparisons, e.g., CPU > 50%.
  * Enhanced Kubernetes Visualization: namespace filters, ReplicaSet/Deployment
    views, extra metadata, better navigation, show Pod logs, delete Pods,
	bugfixes and more ...
  * Scope App performance improvements: ~3X reduction in CPU consumption.


New features and enhancements:
- New search field
	[#1429](https://github.com/weaveworks/scope/pull/1429)
	[#1499](https://github.com/weaveworks/scope/pull/1499)
- Kubernetes improvements:
  - Deployment and Replica Set views
		[#1436](https://github.com/weaveworks/scope/pull/1436)
  - Add scale up/down controls on deployments, replica sets, and replication controllers
		[#1451](https://github.com/weaveworks/scope/pull/1451)
  - Filter by Kubernetes Namespaces
		[#1386](https://github.com/weaveworks/scope/pull/1386)
  - Remove App->Probe deployment ordering restriction
		[#1433](https://github.com/weaveworks/scope/pull/1433)
  - Show Pod IP and # container in the children table in details panel.
		[#1435](https://github.com/weaveworks/scope/pull/1435)
		[#1409](https://github.com/weaveworks/scope/pull/1409)
  - Add pod delete controls
		[#1368](https://github.com/weaveworks/scope/pull/1368)
  - Show the k8s load balancer IP if it is set
		[#1378](https://github.com/weaveworks/scope/pull/1378)
  - Show number of pods in service
		[#1352](https://github.com/weaveworks/scope/pull/1352)
  - Filter GKE system containers
		[#1438](https://github.com/weaveworks/scope/pull/1438)
- Show k8s labels and container env vars in the details panel
	[#1342](https://github.com/weaveworks/scope/pull/1342)
	[#1465](https://github.com/weaveworks/scope/pull/1465)
- Implement `scope help`
	[#1357](https://github.com/weaveworks/scope/pull/1357)
	[#1419](https://github.com/weaveworks/scope/pull/1419)
- Add swarm-agent, swarm-agent master to system container filter
	[#1356](https://github.com/weaveworks/scope/pull/1356)
- Add control for removing stopped docker containers.
	[#1290](https://github.com/weaveworks/scope/pull/1290)
- Add a button to download the report as JSON
	[#1365](https://github.com/weaveworks/scope/pull/1365)
- Use reverse-resolved DNS info in the connections table.
	[#1359](https://github.com/weaveworks/scope/pull/1359)
- Add a 'Unmanaged' node to k8s views which included non-k8s containers.
	[#1350](https://github.com/weaveworks/scope/pull/1350)
- Support docker rename events
	[#1332](https://github.com/weaveworks/scope/pull/1332)
- Strip image version from parent links
	[#1348](https://github.com/weaveworks/scope/pull/1348)
- Add Docker for Mac support
	[#1448](https://github.com/weaveworks/scope/pull/1448)

Performance improvements:
- Scope App:
  - A log(n) complexity report merger
		[#1418](https://github.com/weaveworks/scope/pull/1418)
        [#1447](https://github.com/weaveworks/scope/pull/1447)
  - Don't merge nodes in the rendering pipeline
		[#1398](https://github.com/weaveworks/scope/pull/1398)
  - Pass nil for the decorator in the rendering pipeline when possible
		[#1397](https://github.com/weaveworks/scope/pull/1397)
- Scope Probe:
  - Precompute base of the container nodes
		[#1456](https://github.com/weaveworks/scope/pull/1456)

Bug fixes:
- Correctly attribute DNAT-ed short-lived connections
	[#1410](https://github.com/weaveworks/scope/pull/1410)
- Don't attribute conntracked connections to k8s pause containers.
	[#1415](https://github.com/weaveworks/scope/pull/1415)
- Don't show kubernetes views if not running kubernetes
	[#1364](https://github.com/weaveworks/scope/issues/1364)
- Missing pod names in kubernetes' pod view and Pause containers don't show as children of pods
	[#1412](https://github.com/weaveworks/scope/pull/1412)
- Fix grouped node count for filtered children nodes
	[#1371](https://github.com/weaveworks/scope/pull/1371)
- Don't show container labels on container images
	[#1374](https://github.com/weaveworks/scope/pull/1374)
- `docker rm -f`ed containers linger
	[#1072](https://github.com/weaveworks/scope/issues/1072)
- Somehow internet node goes missing, yet edges are there
	[#1304](https://github.com/weaveworks/scope/pull/1304)
- Node IDs with / leads to redirect loop when scope is mounted under a path with slash redirect
	[#1335](https://github.com/weaveworks/scope/issues/1335)
- Ignore conntracked connections on which we never saw an update
	[#1466](https://github.com/weaveworks/scope/issues/466)
- Containers incorrectly attributed to host
	[#1472](https://github.com/weaveworks/scope/issues/1472)
- k8s: Unexpected edge to the Internet node
	[#1469](https://github.com/weaveworks/scope/issues/1469)
- When user supplies IP addr on command line, we don't try to connect to localhost
	[#1477](https://github.com/weaveworks/scope/issues/1477)
- Wrong host labels on container nodes
	[#1501](https://github.com/weaveworks/scope/issues/1501)

Documentation:
- Restructured Scope Docs
	[#1416](https://github.com/weaveworks/scope/pull/1416)
	[#1479](https://github.com/weaveworks/scope/pull/1479)
- Add ECS instructions and badge to README
	[#1392](https://github.com/weaveworks/scope/pull/1392)
- Document how to access the Scope UI in k8s
	[#1426](https://github.com/weaveworks/scope/pull/1426)
- Update readme to express that daemon sets won't schedule on unschedulable nodes prior to kubernetes 1.2
	[#1434](https://github.com/weaveworks/scope/pull/1434)


Internal improvements and cleanup:
- Migrate from Flux to Redux
	[#1388](https://github.com/weaveworks/scope/pull/1388)
- Add kubernetes checkpoint flag
	[#1391](https://github.com/weaveworks/scope/pull/1391)
- Add generic path rewrite middleware
	[#1381](https://github.com/weaveworks/scope/pull/1381)
- Report hostname and version in probe struct, and version in host node.
	[#1377](https://github.com/weaveworks/scope/pull/1377)
- Reorganise the render/ package
	[#1360](https://github.com/weaveworks/scope/pull/1360)
- Asset fingerprinting
	[#1354](https://github.com/weaveworks/scope/pull/1354)
- Upgrade to go1.6.2
	[#1362](https://github.com/weaveworks/scope/pull/1362)
- Add buffer to mockPublisher channel to prevent deadlock between Publish() and Stop()
	[#1358](https://github.com/weaveworks/scope/pull/1358)
- Add explicit group node summariser instead of doing it in the other summaries
	[#1327](https://github.com/weaveworks/scope/pull/1327)
- Don't build codecs for render/ package anymore.
	[#1345](https://github.com/weaveworks/scope/pull/1345)
- Measure report sizes
	[#1458](https://github.com/weaveworks/scope/pull/1458)

## Release 0.14.0

Highlights:

This release comes with two main new features.
  * Probe plugins: Now you can create your HTTP-based plugin to provide new metrics
    and display them in Scope. You can read more about it and see some examples
    [here](https://github.com/weaveworks/scope/tree/master/examples/plugins).
  * Metrics on canvas: Metrics are now displayed on the nodes and not just on
    the details panel, starting with CPU and memory consumption.

Also, the performance of the UI has been considerably improved and the 100-node
rendering limit has been lifted.


New features and enhancements:
- Probe plugins
	[#1126](https://github.com/weaveworks/scope/pull/1126)
	[#1277](https://github.com/weaveworks/scope/pull/1277)
	[#1280](https://github.com/weaveworks/scope/pull/1280)
	[#1283](https://github.com/weaveworks/scope/pull/1283)
- Metrics on canvas
	[#1105](https://github.com/weaveworks/scope/pull/1105)
	[#1204](https://github.com/weaveworks/scope/pull/1204)
	[#1225](https://github.com/weaveworks/scope/pull/1225)
	[#1243](https://github.com/weaveworks/scope/issues/1243)
- Node details panel improvements
  - Add connection tables
	[#1017](https://github.com/weaveworks/scope/pull/1017)
	[#1248](https://github.com/weaveworks/scope/pull/1248)
  - Layout: make better use of column space
		[#1272](https://github.com/weaveworks/scope/pull/1272)
  - Sparklines
    - Update every second and show 60sec history
			[#795](https://github.com/weaveworks/scope/pull/795)
    - Apply format to tooltips in hovers
			[#1230](https://github.com/weaveworks/scope/pull/1230)
  - Sort numerical entries (e.g. image counts, process IDs) as expected
		[#1125](https://github.com/weaveworks/scope/pull/1125)
  - Remove load5 and load15 metrics
		[#1274](https://github.com/weaveworks/scope/pull/1274)
- Graph view improvements
  - Node filtering improvements
      - Introduce three-way filtering selectors (e.g. choose from _System containers_, _Application containers_ or _Both_)
			[#1159](https://github.com/weaveworks/scope/pull/1159)
      - Maintain node-filtering selection across subviews (e.g. _Containers by ID_ and _Containers by Image_)
			[#1237](https://github.com/weaveworks/scope/pull/1237)
  - Refine maximum length of node names
		[#1263](https://github.com/weaveworks/scope/issues/1263)
		[#1255](https://github.com/weaveworks/scope/pull/1255)
  - Refine border-width of nodes
		[#1138](https://github.com/weaveworks/scope/pull/1138)
		[#1120](https://github.com/weaveworks/scope/pull/1120)
  - Cache pan/zoom per topology
	[#1261](https://github.com/weaveworks/scope/pull/1261)
- Enable launching terminals in hosts
	[#1208](https://github.com/weaveworks/scope/pull/1208)
- Allow pausing the UI through a button
	[#1106](https://github.com/weaveworks/scope/pull/1106)
- Split the internet node for incoming vs outgoing connections.
	[#566](https://github.com/weaveworks/scope/pull/566)
- Show k8s pod status
	[#1289](https://github.com/weaveworks/scope/pull/1289)
- Allow customizing Scope's hostname in Weave Net with `scope launch --weave.hostname`
	[#1041](https://github.com/weaveworks/scope/pull/1041)
- Rename `--weave.router.addr` to `--weave.addr` in the probe for consistency with the app
	[#1060](https://github.com/weaveworks/scope/issues/1060)
- Support new `sha256:` Docker image identifiers
	[#1161](https://github.com/weaveworks/scope/pull/1161)
	[#1184](https://github.com/weaveworks/scope/pull/1184)
- Handle server disconnects gracefully in the UI
	[#1140](https://github.com/weaveworks/scope/pull/1140)


Performance improvements:
  - Performance improvements for UI canvas
	[#1186](https://github.com/weaveworks/scope/pull/1186)
	[#1236](https://github.com/weaveworks/scope/pull/1236)
	[#1239](https://github.com/weaveworks/scope/pull/1239)
	[#1262](https://github.com/weaveworks/scope/pull/1262)
	[#1259](https://github.com/weaveworks/scope/pull/1259)
  - Reduce CPU consumption if UI cannot connect to backend
	[#1229](https://github.com/weaveworks/scope/pull/1229)


Bug Fixes:
- Scope app doesn't correctly expire old reports
	[#1286](https://github.com/weaveworks/scope/issues/1286)
- Container nodes appear without a host label
	[#1065](https://github.com/weaveworks/scope/issues/1065)
- Resizing the window and zooming in/out can confuse window size
	[#1180](https://github.com/weaveworks/scope/issues/1096)
- Link from container -> Pod doesn't work
    [#1180](https://github.com/weaveworks/scope/issues/1293)
- Various websocket and pipe fixes.
	[#1172](https://github.com/weaveworks/scope/pull/1172)
	[#1175](https://github.com/weaveworks/scope/pull/1175)
- Make `--app-only` only run the app and not probe
	[#1067](https://github.com/weaveworks/scope/pull/1067)
- Exported SVG file throws "CANT" error in Adobe Illustrator
	[#1144](https://github.com/weaveworks/scope/issues/1144)
- Docker labels not rendering correctly
	[#1284](https://github.com/weaveworks/scope/issues/1284)
- Error when parsing kernel version in `/proc` background reader
	[#1136](https://github.com/weaveworks/scope/issues/1136)
- Opening the terminal doesn't open work for some containers
	[#1195](https://github.com/weaveworks/scope/issues/1195)
- Terminals: Try to figure what shell to use instead of simply running `/bin/sh`
	[#1069](https://github.com/weaveworks/scope/pull/1069)
- Fix embedded logo size for Safari
	[#1084](https://github.com/weaveworks/scope/pull/1084)
- Don't read from app.Version before we initialise it
	[#1163](https://github.com/weaveworks/scope/pull/1163)
- Don't show multiple pseudo nodes in the host view for the same IP
	[#1155](https://github.com/weaveworks/scope/issues/1155)
- Fix race conditions detected by race detector from Go 1.6
	[#1192](https://github.com/weaveworks/scope/issues/1192)
	[#1087](https://github.com/weaveworks/scope/issues/1087)


Documentation:
- Provide Docker Compose examples for launching the Scope probe with the Scope Cloud Service
	[#1146](https://github.com/weaveworks/scope/pull/1146)

Experimental features:
- Update demo for tracer
	[#1157](https://github.com/weaveworks/scope/pull/1157)


Service-mode related changes:
- Add `/api/probes` endpoint
	[#1265](https://github.com/weaveworks/scope/pull/1265)
- Multitenancy-support improvements
	[#996](https://github.com/weaveworks/scope/pull/996)
	[#1150](https://github.com/weaveworks/scope/pull/1150)
	[#1200](https://github.com/weaveworks/scope/pull/1200)
	[#1241](https://github.com/weaveworks/scope/pull/1241)
	[#1209](https://github.com/weaveworks/scope/pull/1209)
	[#1232](https://github.com/weaveworks/scope/pull/1232)


Internal improvements and cleanup:
- Make node/edge highlighter objects immutable in app store
	[#1173](https://github.com/weaveworks/scope/pull/1173)
- Make cached edge processing more robust
	[#1254](https://github.com/weaveworks/scope/pull/1254)
- Make app-store's topologies object immutable
	[#1167](https://github.com/weaveworks/scope/pull/1167)
- Fix TestCollector test
	[#1070](https://github.com/weaveworks/scope/pull/1070)
- Update docker client, to get better state strings in the UI
	[#1235](https://github.com/weaveworks/scope/pull/1235)
- Upgrade to go1.6
	[#1077](https://github.com/weaveworks/scope/pull/1077)
- React/lodash/babel upgrades + updated linting (linted)
	[#1171](https://github.com/weaveworks/scope/pull/1171)
- Remove address topology
	[#1127](https://github.com/weaveworks/scope/pull/1127)
- Add vendoring docs
	[#1180](https://github.com/weaveworks/scope/pull/1180)
- Fix make client-start
	[#1210](https://github.com/weaveworks/scope/pull/1210)
- Downgrade react-motion
	[#1183](https://github.com/weaveworks/scope/pull/1183)
- Make bin/release work on a mac.
	[#887](https://github.com/weaveworks/scope/pull/887)
- Add various middleware to app.
	[#1234](https://github.com/weaveworks/scope/pull/1234)
- Make unconteinerized build work on OSX
	[#1028](https://github.com/weaveworks/scope/pull/1028)
- Remove codecgen-generated file before building package
	[#1135](https://github.com/weaveworks/scope/pull/1135)
- Build/install packages before invoking codecgen
	[#1042](https://github.com/weaveworks/scope/pull/1042)
- circle.yml: add variable $DOCKER_ORGANIZATION
	[#1083](https://github.com/weaveworks/scope/pull/1083)
- circle.yml: deploy on a personal hub account
	[#1055](https://github.com/weaveworks/scope/pull/1055)
- circle.yml: disable GCE builds when credentials are missing
	[#1054](https://github.com/weaveworks/scope/pull/1054)
- Clean out all the JS in the client build dir.
	[#1205](https://github.com/weaveworks/scope/pull/1205)
- Remove temporary files in the build container to shrink it down by ~100MB
	[#1206](https://github.com/weaveworks/scope/pull/1206)
- Update tools & build container to check for spelling mistakes
	[#1199](https://github.com/weaveworks/scope/pull/1199)
- Fix a couple of minor issue for goreportcard and add badge for it.
	[#1203](https://github.com/weaveworks/scope/pull/1203)

## Release 0.13.1

Bug Fixes:
- Make pipes work with scope.weave.works
  [#1099](https://github.com/weaveworks/scope/pull/1099)
  [#1085](https://github.com/weaveworks/scope/pull/1085)
  [#994](https://github.com/weaveworks/scope/pull/994)
- Don't panic when checking the version fails
  [#1117](https://github.com/weaveworks/scope/pull/1117)

## Release 0.13.0

Note: This release come with big performance improvements, cutting the probe's CPU usage by 70% and the app's CPU usage by up to 85%. See detailed performance improvement-related changes below:

Performance improvements:
- Improve codec performance
	[#916](https://github.com/weaveworks/scope/pull/916)
  [#1002](https://github.com/weaveworks/scope/pull/1002)
  [#1005](https://github.com/weaveworks/scope/pull/1005)
  [#980](https://github.com/weaveworks/scope/pull/980)
- Reduce amount of objects allocated by the codec
	[#1000](https://github.com/weaveworks/scope/pull/1000)
- Refactor app for multitenancy
	[#997](https://github.com/weaveworks/scope/pull/997)
- Improve performance of docker stats obtention
	[#989](https://github.com/weaveworks/scope/pull/989)
- Rate-limit reading proc files
	[#912](https://github.com/weaveworks/scope/pull/912)
  [#905](https://github.com/weaveworks/scope/pull/905)
- Compile k8s selectors once (not for each pod)
	[#918](https://github.com/weaveworks/scope/pull/918)
- Fix reading of network namespace inodes
	[#898](https://github.com/weaveworks/scope/pull/898)

New features and enhancements:
- Node shapes for different topologies, e.g. heptagons for Kubernetes pods
  [#884](https://github.com/weaveworks/scope/pull/884)
	[#1006](https://github.com/weaveworks/scope/pull/1006)
	[#1037](https://github.com/weaveworks/scope/pull/1037)
- Force-relayout button that may help with topology layouts that have lots of edge crossings
	[#981](https://github.com/weaveworks/scope/pull/981)
- Download button to save the current node graph as SVG file
	[#1027](https://github.com/weaveworks/scope/pull/1027)
- Replace Show More buttons with carets w/ counts
  [#1012](https://github.com/weaveworks/scope/pull/1012)
	[#1029](https://github.com/weaveworks/scope/pull/1029)
- Improve contrast of default view
	[#979](https://github.com/weaveworks/scope/pull/979)
- High contrast mode button for viewing scope on projectors
	[#954](https://github.com/weaveworks/scope/pull/954)
	[#984](https://github.com/weaveworks/scope/pull/984)
- Gather file descriptors as process metric
	[#961](https://github.com/weaveworks/scope/pull/961)
- Show Docker Labels in their own table in details panel
	[#904](https://github.com/weaveworks/scope/pull/904)
	[#965](https://github.com/weaveworks/scope/pull/965)
- Improve highlighting of selected topology
	[#936](https://github.com/weaveworks/scope/pull/936)
  [#964](https://github.com/weaveworks/scope/pull/964)
- Details: only show important metadata by default, expand the rest
	[#946](https://github.com/weaveworks/scope/pull/946)
- Reorder the children tables in the details panel by importance
	[#941](https://github.com/weaveworks/scope/pull/941)
- Shorten docker container and image IDs in the details panel.
	[#930](https://github.com/weaveworks/scope/pull/930)
- Shorten some details panel labels which were truncated
	[#940](https://github.com/weaveworks/scope/pull/940)
- Add Container Count column to container images table
	[#919](https://github.com/weaveworks/scope/pull/919)
- Periodically check for newer versions of scope.
	[#907](https://github.com/weaveworks/scope/pull/907)
- Rename Applications -> Process, sort topologies by rank.
	[#866](https://github.com/weaveworks/scope/pull/866)
- Rename 'by hostname' to 'by dns name'
	[#856](https://github.com/weaveworks/scope/pull/856)
- Add container uptime and restart count to details panel.
	[#853](https://github.com/weaveworks/scope/pull/853)
- Use connection directions from conntrack for improved layout flow
	[#967](https://github.com/weaveworks/scope/pull/967)
- Support for container controls in Kubernetes
  [#1043](https://github.com/weaveworks/scope/pull/1043)
- Add debug logging
	[#935](https://github.com/weaveworks/scope/pull/935)

Bug fixes:
- Use TCP for weave dns to fix autoclustering
  [#1038](https://github.com/weaveworks/scope/pull/1038)
- Add ping/pong to websocket protocol to prevent websocket connections being dropped when traversing loadbalancers
	[#995](https://github.com/weaveworks/scope/pull/995)
- Handle closing of docker events channel gracefully
	[#1014](https://github.com/weaveworks/scope/pull/1014)
- Don't show blank IPs metadata row for containers with no IP
	[#960](https://github.com/weaveworks/scope/pull/960)
- Remove pointer math (comparison) from render caching, as it is unreliable
	[#962](https://github.com/weaveworks/scope/pull/962)
- set TERM=xterm on execs to work around docker issue 9299
	[#969](https://github.com/weaveworks/scope/pull/969)
- Fix weave tagger crash
	[#976](https://github.com/weaveworks/scope/pull/976)
- Use Sirupsen/logrus logger in the Weave tagger
	[#974](https://github.com/weaveworks/scope/pull/974)
- Fix JSON encoding for fixedprobe
	[#975](https://github.com/weaveworks/scope/pull/975)
- Don't render any metrics/metadata for uncontained node
	[#956](https://github.com/weaveworks/scope/pull/956)
- Update go-dockerclient to fix bug with docker 1.10
	[#952](https://github.com/weaveworks/scope/pull/952)
- Show nice column labels when no children have metrics
	[#950](https://github.com/weaveworks/scope/pull/950)
- Fixes process-by-name layout with ./foo and /foo nodes
	[#948](https://github.com/weaveworks/scope/pull/948)
- Deal with starting / stopping weave whilst scope is running
	[#867](https://github.com/weaveworks/scope/pull/867)
- Remove host links that link to themselves in details panel
	[#917](https://github.com/weaveworks/scope/pull/917)
- Just show the untruncated label in the tooltip on children
	[#911](https://github.com/weaveworks/scope/pull/911)
- Taking a read lock twice only works most of the time.
	[#889](https://github.com/weaveworks/scope/pull/889)
- Details panel table header looks up label in all rows
	[#895](https://github.com/weaveworks/scope/pull/895)
- Fixes some fields overflowing badly in details panel in Chrome 48
	[#892](https://github.com/weaveworks/scope/pull/892)
- Stop details cards popping up over the terminal.
	[#882](https://github.com/weaveworks/scope/pull/882)
- Fixes host node/details panel color mismatch
	[#880](https://github.com/weaveworks/scope/pull/880)
- Don't log expected websocket errors
	[#1024](https://github.com/weaveworks/scope/pull/1024)
- Overwrite /etc/weave/apps, because it might already exist
	[#959](https://github.com/weaveworks/scope/pull/959)
- Log a warning when reporters or taggers take too long to generate
	[#944](https://github.com/weaveworks/scope/pull/944)
- Minor refactor of backend metadata and metric rendering
	[#920](https://github.com/weaveworks/scope/pull/920)
- Add some tests, and a zero-value for report.Sets
	[#903](https://github.com/weaveworks/scope/pull/903)

Build improvements and cleanup:
- Disable checkpointing in tests.
	[#1031](https://github.com/weaveworks/scope/pull/1031)
- Turn off GC for builds.
	[#1023](https://github.com/weaveworks/scope/pull/1023)
- Bump template name to get latest version of docker.
	[#998](https://github.com/weaveworks/scope/pull/998)
- Fixes building scope outside of a container.
	[#901](https://github.com/weaveworks/scope/pull/901)
- Don't need sudo when DOCKER_HOST is tcp.
	[#888](https://github.com/weaveworks/scope/pull/888)
- Disable npm progress to speed up build
	[#894](https://github.com/weaveworks/scope/pull/894)
- Refactoring deepequal to satisfy linter
	[#890](https://github.com/weaveworks/scope/pull/890)

Documentation:
- Document how to obtain profiles without `go tool pprof`
	[#993](https://github.com/weaveworks/scope/pull/993)
- Use short URL for scope download
	[#1018](https://github.com/weaveworks/scope/pull/1018)
- Added note about docker and go dependency to the readme
	[#966](https://github.com/weaveworks/scope/pull/966)
- Update readme and images.
	[#885](https://github.com/weaveworks/scope/pull/885)
- Update approach to trigger signal dumps
	[#883](https://github.com/weaveworks/scope/pull/883)


## Release 0.12.0

New features and enhancements:
- New, interactive contextual details panel
  [#752](https://github.com/weaveworks/scope/pull/752)
- Gather per-process CPU and memory metrics
  [#767](https://github.com/weaveworks/scope/pull/767)
- k8s: Use service account token by default and improve error logging
  [#808](https://github.com/weaveworks/scope/pull/808)
- k8s: Filter out pause as a system container to declutter view
  [#823](https://github.com/weaveworks/scope/pull/823)
- k8s: Render container names from label "io.kubernetes.container.name"
  [#810](https://github.com/weaveworks/scope/pull/810)
- Probes now use TLS against scope.weave.works by default
  [#785](https://github.com/weaveworks/scope/pull/785)
- Allow dismissing a disconnected terminal w/ \<esc\>
  [#819](https://github.com/weaveworks/scope/pull/819)

Bug fixes:
- General k8s fixups
  [#834](https://github.com/weaveworks/scope/pull/834)
- Use argv\[0\] for process name, differentiate scope app and probe.
  [#796](https://github.com/weaveworks/scope/pull/796)
- Don't panic if you don't understand the message on the control WS.
  [#793](https://github.com/weaveworks/scope/pull/793)
- Highlight a single unconnected node on hover.
  [#790](https://github.com/weaveworks/scope/pull/790)
- Fixes to Terminal resizing and key support
  [#766](https://github.com/weaveworks/scope/pull/766)
  [#780](https://github.com/weaveworks/scope/pull/780)
  [#817](https://github.com/weaveworks/scope/pull/817)
- Correctly collapse nodes in the Container Images view when they use non-standard port.
  [#824](https://github.com/weaveworks/scope/pull/824)
- Stop scope crashing chrome when we get "long" edges.
  [#837](https://github.com/weaveworks/scope/pull/837)
- Fix node controls so they behave independently across nodes
  [#797](https://github.com/weaveworks/scope/pull/797)

Build improvements and cleanup:
- Update to latest tools.git
  [#816](https://github.com/weaveworks/scope/pull/816)
- Update to latest go-dockerclient
  [#788](https://github.com/weaveworks/scope/pull/788)
- Speed up builds
  [#775](https://github.com/weaveworks/scope/pull/775)
  [#789](https://github.com/weaveworks/scope/pull/789)
- Speed up tests
  [#799](https://github.com/weaveworks/scope/pull/799)
  [#807](https://github.com/weaveworks/scope/pull/807)
- Split and move xfer package.
  [#794](https://github.com/weaveworks/scope/pull/794)
- Add more tests to procspy
  [#751](https://github.com/weaveworks/scope/pull/751)
  [#781](https://github.com/weaveworks/scope/pull/781)
- Build example app in container.
  [#831](https://github.com/weaveworks/scope/pull/831)
- Various improvements to build & test
  [#829](https://github.com/weaveworks/scope/pull/829)

## Release 0.11.1

Bug fix:
- Scrape /proc/PID/net/tcp6 such that we see both ends of local connections
  [change](https://github.com/weaveworks/scope/commit/550f21511a2da20717c6de6172b5bf2e9841d905)

## Release 0.11.0

New features:

- Add a terminal to the UI with the ability to `attach` to, or `exec` a shell in, a Docker container.
  [#650](https://github.com/weaveworks/scope/pull/650)
  [#735](https://github.com/weaveworks/scope/pull/735)
  [#726](https://github.com/weaveworks/scope/pull/726)
- Added `scope version` command
  [#750](https://github.com/weaveworks/scope/pull/750)
- Various CPU usage reductions for probe
  [#742](https://github.com/weaveworks/scope/pull/742)
  [#741](https://github.com/weaveworks/scope/pull/741)
  [#737](https://github.com/weaveworks/scope/pull/737)
- Show hostname of app you are connected to in the bottom right of the UI
  [#707](https://github.com/weaveworks/scope/pull/707)
- Add host memory and CPU usage metrics to the details panel
  [#711](https://github.com/weaveworks/scope/pull/711)
- Add json support to app POST /api/report
  [#722](https://github.com/weaveworks/scope/pull/722)
- Update the docker version we embed into the scope image to 1.6.2 in sync with weave 1.3 changes.
  [#702](https://github.com/weaveworks/scope/pull/702)
- Show a spinner while node details are loading
  [#691](https://github.com/weaveworks/scope/pull/691)
- Deterministic coloring of nodes based on rank and label
  [#694](https://github.com/weaveworks/scope/pull/694)

Bug fixes:

- Mitigate one-line-of-nodes layouts (when graph has few connections), layout in rectangle instead
  [#679](https://github.com/weaveworks/scope/pull/679)
- When filtering unconnected nodes in the processes view, also filter nodes that are only connected to themselves.
  [#706](https://github.com/weaveworks/scope/pull/706)
- Correctly hide container based on docker labels on the container image.
  [#705](https://github.com/weaveworks/scope/pull/705)
- Show details for stopped container in the default view, by not applying filters to the node details endpoints.
  [#704](https://github.com/weaveworks/scope/pull/704)
  [#701](https://github.com/weaveworks/scope/pull/701)
- Fix render issues in Safari
  [#686](https://github.com/weaveworks/scope/pull/686)
- Take default topology option if missing in URL
  [#678](https://github.com/weaveworks/scope/pull/678)
- Don't treat missing node as UI error
  [#677](https://github.com/weaveworks/scope/pull/677)
- Unset previous details when deselecting a node
  [#675](https://github.com/weaveworks/scope/pull/675)
- Add x to close details panel again
  [#673](https://github.com/weaveworks/scope/pull/673)

Documentation:

- Add basic security warning.
  [#703](https://github.com/weaveworks/scope/pull/703)
- Add basic kubernetes how-to to the readme
  [#669](https://github.com/weaveworks/scope/pull/669)
- Document debug options for developers
  [#723](https://github.com/weaveworks/scope/pull/723)
- Add 'getting help' section and update screenshot
  [#709](https://github.com/weaveworks/scope/pull/709)

Build improvements and cleanup:

- Don't go get weave, git clone it so weave build errors don't affect Scope.
  [#743](https://github.com/weaveworks/scope/pull/743)
- Reduce image size and build time by merging scope probe and app binaries.
  [#732](https://github.com/weaveworks/scope/pull/732)
- Cleaning up some dead code around edges and edgemetadata
  [#730](https://github.com/weaveworks/scope/pull/730)
- Make `make` build  the UI
  [#728](https://github.com/weaveworks/scope/pull/728)
- Omit controls field from json if empty.
  [#725](https://github.com/weaveworks/scope/pull/725)
- JS to ES2015
  [#712](https://github.com/weaveworks/scope/pull/712)
- Upgraded react to 0.14.3
  [#687](https://github.com/weaveworks/scope/pull/687)
- Cleaned up node-details-table
  [#676](https://github.com/weaveworks/scope/pull/676)
- Fix react key warning
  [#672](https://github.com/weaveworks/scope/pull/672)

## Release 0.10.0

Notes:
- Due to the Scope UI now being able to start/stop/restart Docker
  containers, it is not wise to have it accessible to untrusted
  parties.

New features:
- Add lifecycle controls (start/stop/restart) for Docker containers
  [#598](https://github.com/weaveworks/scope/pull/598)
  [#642](https://github.com/weaveworks/scope/pull/642)
- Add sparklines to the UI for some metrics
  [#622](https://github.com/weaveworks/scope/pull/622)
- Show a message when the selected topology is empty
  [#505](https://github.com/weaveworks/scope/pull/505)

Bug fixes:
- Change node layout incrementally to reduce re-layouts
  [#593](https://github.com/weaveworks/scope/pull/593)
- Improve responsiveness of UI updates to container state changes
  [#628](https://github.com/weaveworks/scope/pull/628)
  [#640](https://github.com/weaveworks/scope/pull/640)
- Handle DNS Resolution to a set of names
  [#639](https://github.com/weaveworks/scope/pull/639)
- Correctly show node counts for sub-topologies
  [#621](https://github.com/weaveworks/scope/issues/621)
- Allow scope to start after being upgraded
  [#617](https://github.com/weaveworks/scope/pull/617)
- Prevent a stranded pseudo-nodes from appearing in the container view
  [#627](https://github.com/weaveworks/scope/pull/627)
  [#674](https://github.com/weaveworks/scope/pull/674)
- Parallelise and improve the testing infrastructure
  [#614](https://github.com/weaveworks/scope/pull/614)
  [#618](https://github.com/weaveworks/scope/pull/618)
  [#644](https://github.com/weaveworks/scope/pull/644)

## Release 0.9.0

New features:
- Add basic Kubernetes views for pods and services
  [#441](https://github.com/weaveworks/scope/pull/441)
- Support for Weave 1.2
  [#574](https://github.com/weaveworks/scope/pull/574)
- Add containers-by-hostname view
  [#545](https://github.com/weaveworks/scope/pull/545)
- Build using Go 1.5, with vendored dependencies
  [#584](https://github.com/weaveworks/scope/pull/584)
- Make `scope launch` work from remote hosts, with an appropriately defined DOCKER_HOST
  [#524](https://github.com/weaveworks/scope/pull/524)
- Increase DNS poll frequency such that Scope clusters more quickly
  [#524](https://github.com/weaveworks/scope/pull/524)
- Add `scope command` for printing the Docker commands used to run Scope
  [#553](https://github.com/weaveworks/scope/pull/553)
- Include some basic documentation on how to run Scope
  [#572](https://github.com/weaveworks/scope/pull/572)
- Warn if the user tries to run Scope on Docker versions <1.5.0
  [#557](https://github.com/weaveworks/scope/pull/557)
- Add support for loading the Scope UI from https endpoints
  [#572](https://github.com/weaveworks/scope/pull/572)
- Add support for probe sending reports to https endpoints
  [#575](https://github.com/weaveworks/scope/pull/575)

Bug fixes:
- Correctly track short-lived connections from the internet
  [#493](https://github.com/weaveworks/scope/pull/493)
- Fix a corner case where short-lived connections between containers are incorrectly attributed
  [#577](https://github.com/weaveworks/scope/pull/577)
- Ensure service credentials are sent when doing initial probe<->app handshake
  [#564](https://github.com/weaveworks/scope/pull/564)
- Sort reverse-DNS-resolved names to mitigate some UI fluttering
  [#562](https://github.com/weaveworks/scope/pull/562)
- Don't leak goroutines in the probe
  [#531](https://github.com/weaveworks/scope/issues/531)
- Rerun background conntrack processes if they fail
  [#581](https://github.com/weaveworks/scope/issues/581)
- Build and test using Go 1.5 and vendor all dependencies
  [#584](https://github.com/weaveworks/scope/pull/584)
- Fix "close on nil channel" error on shutdown
  [#599](https://github.com/weaveworks/scope/issues/599)

## Release 0.8.0

New features:
- Show message in the UI when topologies exceed size limits.
  [#474](https://github.com/weaveworks/scope/issues/474)
- Provide container image information in detail pane for containers.
  [#398](https://github.com/weaveworks/scope/issues/398)
- When filtering out system containers, also filter out pseudo nodes, if they were only connected to system containers.
  [#483](https://github.com/weaveworks/scope/issues/483)
- Show number of filtered nodes in status pane.
  [#509](https://github.com/weaveworks/scope/issues/509)

Bug fixes:
- Prevent detail pane from hiding nodes on click-to-focus.
  [#495](https://github.com/weaveworks/scope/issues/495)
- Stop radial view from bouncing in some circumstances.
  [#496](https://github.com/weaveworks/scope/issues/496)
- Make NAT tracking component more resilient to failure.
  [#506](https://github.com/weaveworks/scope/issues/506)
- Prevent duplicate reports from reaching the same app.
  [#463](https://github.com/weaveworks/scope/issues/463)
- Improve consistency of edge directionality in some use-cases.
  [#373](https://github.com/weaveworks/scope/issues/373)
- Ensure probe, app, and container shut down cleanly.
  [#424](https://github.com/weaveworks/scope/issues/424)
  [#478](https://github.com/weaveworks/scope/issues/478)

## Release 0.7.0

New features:
- Show short-lived connections in the containers view.
  [#356](https://github.com/weaveworks/scope/issues/356)
  [#447](https://github.com/weaveworks/scope/issues/447)
- Details pane:
  1. Add more information:
    - Docker labels.
      [#400](https://github.com/weaveworks/scope/pull/400)
    - Weave IPs/hostnames/MACs and Docker IPs.
      [#394](https://github.com/weaveworks/scope/pull/394)
      [#396](https://github.com/weaveworks/scope/pull/396)
    - Host/container context when ambiguous.
      [#387](https://github.com/weaveworks/scope/pull/387)
  2. Present it in a more intuitive way:
    - Show hostnames instead of IPs when possible.
      [#404](https://github.com/weaveworks/scope/pull/404)
      [#451](https://github.com/weaveworks/scope/pull/451)
    - Merge all the connection-related information into a single table.
      [#322](https://github.com/weaveworks/scope/issues/322)
    - Include relevant information in the table titles.
      [#387](https://github.com/weaveworks/scope/pull/387)
    - Stop including empty fields.
      [#370](https://github.com/weaveworks/scope/issues/370)
- Allow filtering out system containers (e.g. Weave and Scope containers) and
  unconnected containers. System containers are filtered out by default.
  [#420](https://github.com/weaveworks/scope/pull/420)
  [#337](https://github.com/weaveworks/scope/issues/337)
  [#454](https://github.com/weaveworks/scope/issues/454)
  [#457](https://github.com/weaveworks/scope/issues/457)
- Improve rendering by making edges' directions flow from client to server.
  [#355](https://github.com/weaveworks/scope/pull/355)
- Highlight selected node
  [#473](https://github.com/weaveworks/scope/pull/473)
- Animate Edges during UI transtions
  [#445](https://github.com/weaveworks/scope/pull/445)
- New status bar on the bottom left of the UI
  [#487](https://github.com/weaveworks/scope/pull/487)
- Show more information for pseudo nodes where possible - such as processes for uncontained, and connected to/from the internet.
  [#249](https://github.com/weaveworks/scope/issues/249)
  [#401](https://github.com/weaveworks/scope/pull/401)
  [#426](https://github.com/weaveworks/scope/pull/426)
- Truncate node names and text in the details pane.
  [#429](https://github.com/weaveworks/scope/pull/429)
  [#430](https://github.com/weaveworks/scope/pull/430)
- Amazon ECS: Stop displaying mangled container names, display the original Container Definition name instead.
  [#456](https://github.com/weaveworks/scope/pull/456)
- Annotate processes in containers with the container name, in the *Applications* view.
  [#331](https://github.com/weaveworks/scope/issues/331)
- Improve graph transitions between updates.
  [#379](https://github.com/weaveworks/scope/pull/379)
- Reduce CPU usage of Scope probes
  [#470](https://github.com/weaveworks/scope/pull/470)
  [#484](https://github.com/weaveworks/scope/pull/484)
- Make report propagation more reliable
  [#459](https://github.com/weaveworks/scope/pull/459)
- Support Weave 1.1 status interface
  [#389](https://github.com/weaveworks/scope/pull/389)

Bug fixes:
- *Trying to reconnect..* in UI even though its connected.
  [#392](https://github.com/weaveworks/scope/pull/392)
- The *Applications* view goes blank after a few seconds.
  [#442](https://github.com/weaveworks/scope/pull/442)
- Frequently getting disconnected lines in UI
  [#460](https://github.com/weaveworks/scope/issues/460)
- Panic due to closing request body
  [#480](https://github.com/weaveworks/scope/pull/480)

## Release 0.6.0

New features:
- Probes now push data to the app, instead of the app pulling it.
  [#342](https://github.com/weaveworks/scope/pull/342)
- Allow probe and app to be started independently, via --no-app and
  --no-probe flags.
  [#345](https://github.com/weaveworks/scope/pull/345)
- Close details pane when changing topology view.
  [#297](https://github.com/weaveworks/scope/issues/297)
- Add support for --probe.foo=bar style flags, in addition to
  --probe.foo bar, which is already supported.
  [#347](https://github.com/weaveworks/scope/pull/347)
- Added X-Scope-Probe-ID header to identify probes when sending
  information to the app.
  [#351](https://github.com/weaveworks/scope/pull/351)

Bug fixes:
- Update scope script to work with master version of weave, where DNS
  has been embedded in the router.
  [#321](https://github.com/weaveworks/scope/issues/321)
- Fixed regression where process names weren't appearing for Darwin
  probes.
  [#320](https://github.com/weaveworks/scope/pull/320)
- Fixed rendering bug resulting in orphaned nodes.
  [#339](https://github.com/weaveworks/scope/pull/339)
- App now only logs to stderr, to match the probe.
  [#343](https://github.com/weaveworks/scope/pull/343)
- Use relative paths for all URLs in the UI.
  [#344](https://github.com/weaveworks/scope/pull/344)
- Removed temporary containers created by the scope script.
  [#348](https://github.com/weaveworks/scope/issues/348)

Experimental features:
- Added support for pcap based packet sniffing, to provide bandwidth
  usage information. It can be enabled via the --capture flag. When
  enabled the probe will monitor packets for a portion of the time, and
  estimate bandwidth usage. Network throughput will be affected if
  capture is enabled.
  [#317](https://github.com/weaveworks/scope/pull/317)


## Release 0.5.0

New features:
- Aggregate all connection information into a single table in the details
  dialog.
  [#298](https://github.com/weaveworks/scope/pull/298)
- Renamed binaries to scope-app and scope-probe
  [#293](https://github.com/weaveworks/scope/pull/293)
- Group containers topology by name only, and not version
  [#291](https://github.com/weaveworks/scope/issues/291)
- Make intra-scope communication traverse the weave network if present.
  [#71](https://github.com/weaveworks/scope/issues/71)

Bug fixes:
- Reduced memory usage
  [#266](https://github.com/weaveworks/scope/issues/266)


## Release 0.4.0

New features:
- Include kernel version and uptime in host details.
  [#274](https://github.com/weaveworks/scope/pull/274)
- Include command line and number of threads in process details.
  [#272](https://github.com/weaveworks/scope/pull/272)
- Include Docker port mapping, entrypoint, memory usage and creation
  date in container details.
  [#262](https://github.com/weaveworks/scope/pull/262)
- Order tables in details panel from least granular to most granular.
  [#261](https://github.com/weaveworks/scope/issues/261)
- Show all container images (even ones without active connections)
  in the containers-by-image view.
  [#230](https://github.com/weaveworks/scope/issues/230)
- Produce process and container views by merging endpoint topology with their
  respective topologies, such that the origins in the details panel always
  aggregate correctly. [#228](https://github.com/weaveworks/scope/issues/228)
- In containers view, show "Uncontained" nodes for each host if they have
  active connections. [#127](https://github.com/weaveworks/scope/issues/127)
- Show connection status in the UI.
  [#162](https://github.com/weaveworks/scope/issues/162)

Bug fixes:
- Reduce CPU usage by caching walks of /proc.
  [#284](https://github.com/weaveworks/scope/issues/284)
- Trim whitespace of process names such that the details panel functions
  correctly in the process-by-name view.
  [#281](https://github.com/weaveworks/scope/issues/281)
- Correctly scope addresses on Docker bridge such that processes on different
  hosts are not incorrectly shown as communicating.
  [#264](https://github.com/weaveworks/scope/pull/264)
- Correctly show connections between nodes which traverse a Docker port
  mapping. [#245](https://github.com/weaveworks/scope/issues/245)
- Make scope script fail if docker run fails.
  [#214](https://github.com/weaveworks/scope/issues/214)
- Prevent left over nodes in the UI when the connection is dropped or Scope is
  restarted. [#162](https://github.com/weaveworks/scope/issues/162)


## Release 0.3.0

- Show containers, even when they aren't communicating.
- Expand topology selectors more descriptive, and remove the grouping button.
- Fix overflow rendering bugs in the detail pane.
- Render pseudonodes with less saturation.

## Release 0.2.0

- Initial release.
